package ClinicasUpao.ClinicasUpaoG3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClinicasUpaoG3Application {

	public static void main(String[] args) {
		SpringApplication.run(ClinicasUpaoG3Application.class, args);
	}

}
