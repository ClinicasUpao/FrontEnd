package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;
import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "Antecedentes")
@Data
public class Antecedente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "antecedenteId")
    private Long antecedenteId;

    @Column(name = "alergias", nullable = false, length = 100)
    private String alergias;

    @Column(name = "cirugias", nullable = false, length = 100)
    private String cirugias;

    @Column(name = "enfermedadesprevias", nullable = false, length = 100)
    private String enfermedadesprevias;

    @OneToOne(mappedBy = "antecedente")
    private HistoriaClinica historiaClinica;
}
