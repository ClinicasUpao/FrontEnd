package ClinicasUpao.ClinicasUpaoG3.Domain.Enum;
public enum TipoDocumento {
    DNI,
    CARNET_EXTRANJERIA,
    PASAPORTE
}
