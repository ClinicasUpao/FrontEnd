package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;
import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
@Table(name = "historia_clinica")
public class HistoriaClinica {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "historiaClinicaId")
    private Long historiaClinicaId;

    @OneToOne
    @JoinColumn(name = "usuario_id", referencedColumnName = "id", nullable = false)
    private Paciente paciente;

    @OneToMany(mappedBy = "historiaClinica", cascade = CascadeType.ALL)
    private List<Diagnostico> diagnosticos;

    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "antecedente_id", referencedColumnName = "antecedenteId", nullable = false)
    private Antecedente antecedente;
}
