package ClinicasUpao.ClinicasUpaoG3.Domain.Enum;



public enum ERole {
    PACIENTE,
    MEDICO
}
