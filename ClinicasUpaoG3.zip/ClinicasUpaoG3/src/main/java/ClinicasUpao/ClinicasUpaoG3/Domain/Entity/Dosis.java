package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Dosis")
public class Dosis {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Cantidad", nullable = false)
    private Double cantidad;

    @Column(name = "Frecuencia", nullable = false)
    private String frecuencia;

    @ManyToOne
    @JoinColumn(name = "receta_id", referencedColumnName = "recetaId", nullable = false)
    private Receta receta;

    @ManyToOne
    @JoinColumn(name = "farmaco_id", referencedColumnName = "farmacoId", nullable = false)
    private Farmaco farmaco;
}