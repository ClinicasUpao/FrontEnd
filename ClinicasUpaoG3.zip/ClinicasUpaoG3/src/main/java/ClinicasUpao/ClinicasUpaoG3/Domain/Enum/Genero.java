package ClinicasUpao.ClinicasUpaoG3.Domain.Enum;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum Genero {
    MASCULINO, FEMININO;
    @JsonCreator
    public static Genero fromString(String value) {
        return Genero.valueOf(value.toUpperCase());
    }
}
