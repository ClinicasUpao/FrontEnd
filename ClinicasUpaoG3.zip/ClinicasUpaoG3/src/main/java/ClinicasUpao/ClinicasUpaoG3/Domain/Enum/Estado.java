package ClinicasUpao.ClinicasUpaoG3.Domain.Enum;


public enum Estado {
    PENDIENTE,
    CONFIRMADA,
    REALIZADA,
    CANCELADA,
    REPROGRAMADA,
}
