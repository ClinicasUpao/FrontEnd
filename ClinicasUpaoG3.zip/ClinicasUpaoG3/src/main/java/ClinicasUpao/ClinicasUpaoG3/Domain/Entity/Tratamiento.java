package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;


import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
@Table(name = "Tratamiento")
public class Tratamiento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "Descripcion", nullable = false, length = 255)
    private String descripcion;

    @ManyToOne
    @JoinColumn(name = "diagnostico_id", referencedColumnName = "diagnosticoId")
    private Diagnostico diagnostico;

    @OneToMany(mappedBy = "tratamiento", cascade = CascadeType.ALL)
    private List<Receta> recetas;
}
