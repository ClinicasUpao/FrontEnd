package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
@Table(name = "Farmaco")

public class Farmaco {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long farmacoId;

    @Column(name = "Descripcion", nullable = false)
    private String descripcion;

    @Column(name = "Efectos_secundarios", nullable = false)
    private String efectosSecundarios;

    @Column(name = "Nombre", nullable = false)
    private String nombre;

    @OneToMany(mappedBy = "farmaco")
    private List<Dosis> dosis;
}
