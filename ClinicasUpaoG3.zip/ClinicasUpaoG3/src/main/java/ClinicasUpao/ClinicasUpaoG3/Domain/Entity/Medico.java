package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Genero;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.TipoDocumento;
import jakarta.persistence.*;
import lombok.Data;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.time.LocalDate;
import java.time.Period;
import java.util.Collection;
import java.util.List;

@Data
@Entity
@Table(name = "medico")
public class Medico implements UserDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nombre", nullable = false, length = 50)
    private String nombre;

    @Column(name = "apellido", nullable = false, length = 50)
    private String apellido;

    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;

    @Column(name = "contrasena", nullable = false, length = 100)
    private String contrasena;

    @Column(name = "telefono", nullable = false, length = 15)
    private String telefono;

    @Column(name = "fecha_nacimiento", nullable = false)
    private LocalDate fechaNacimiento;

    @Column(name = "username", unique = true)
    private String username;

    @Enumerated(EnumType.STRING)
    @Column(name = "genero", nullable = false)
    private Genero genero;

    @Column(name = "pais_origen", nullable = false)
    private String paisOrigen;

    @Column(name = "departamento", nullable = false, length = 25)
    private String departamento;

    @Column(name = "distrito", nullable = false, length = 25)
    private String distrito;

    @Column(name = "direccion", nullable = false, length = 100)
    private String direccion;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_documento", nullable = false, length = 20)
    private TipoDocumento tipoDocumento;

    @Column(name = "colegiatura", nullable = false, length = 20)
    private String colegiatura;

    @Column(name = "especialidad", nullable = false, length = 25)
    private String especialidad;

    @Column(name = "especialidad_licencia", nullable = true, length = 255)
    private String especialidadLicencia;

    @Column(name = "facultad_egreso", nullable = true, length = 25)
    private String facultadEgreso;

    @Column(name = "registro_especialidad", nullable = true, length = 255)
    private String registroEspecialidad;

    @Column(name = "subespecialidad", nullable = true, length = 25)
    private String subespecialidad;

    @Column(name = "subespecialidad_licencia", nullable = true, length = 255)
    private String subespecialidadLicencia;

    @Column(name = "documento_identidad", nullable = false, unique = true)
    private String documentoIdentidad;

    @Column(name = "certificaciones", nullable = true, length = 255)
    private String certificaciones;

    @OneToMany(mappedBy = "medico", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Intervalo> intervalos;

    @OneToMany(mappedBy = "medico", cascade = CascadeType.ALL)
    private List<Cita> citas;

    @OneToOne
    @JoinColumn(name = "usuario_id", referencedColumnName = "id")
    private Usuario usuario;

    public void generarUsername() {
        if (nombre != null && apellido != null) {
            this.username = (nombre + apellido).toLowerCase();
        }
    }

    public int getEdad() {
        if (this.fechaNacimiento != null) {
            return Period.between(this.fechaNacimiento, LocalDate.now()).getYears();
        }
        return 0;
    }

    // Implementación de UserDetails
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // Aquí puedes retornar roles o permisos del médico
        return null; // Cambia esto según tu lógica de autorización
    }

    @Override
    public String getPassword() {
        return this.contrasena;
    }

    @Override
    public String getUsername() {
        return this.username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
