package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Genero;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.TipoDocumento;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;

@Data
@Entity
@Table(name = "Pacientes")
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Paciente  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(name = "nombre", nullable = false, length = 50)
    private String nombre;

    @Column(name = "apellido", nullable = false, length = 50)
    private String apellido;

    @Column(name = "email", nullable = false, unique = true, length = 100)
    private String email;

    @Column(name = "contrasena", nullable = false, length = 100)
    private String contrasena;

    @Column(name = "telefono", nullable = false, length = 15)
    private String telefono;

    @Temporal(TemporalType.DATE)
    @Column(name = "fecha_nacimiento", nullable = false)
    private LocalDate fechaNacimiento;

    public int getEdad(){
        if(this.fechaNacimiento != null){
            return 0;
        }
        return
                Period.between(this.fechaNacimiento, LocalDate.now()).getYears();
    }
    @Enumerated(EnumType.STRING)
    @Column(name = "genero", nullable = false)
    private Genero genero;
    @Column(name= "paisdeOrigen",nullable = false)
    private String paisOrigen;
    @Column(name = "departamento",nullable = false, length = 25)
    private String departamento;
    @Column(name = "distrito",nullable = false, length = 25)
    private String distrito;
    @Column(name = "direccion",nullable = false, length = 100)
    private String direccion;
    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_documento", nullable = false, length = 20)
    private TipoDocumento tipoDocumento;
    @Column(name = "documento_identidad", nullable = false, unique = true)
    private String documentoIdentidad;
    @Column(name = "Seguro", nullable = true)
    private String seguro;
    @Column(name = "created_at",nullable = false)
    private LocalDateTime created_at;
    @Column(name = "updated_at",nullable = false)
    private LocalDateTime updated_at;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "registroInmunologicoId", referencedColumnName = "registroInmunologicoId")
    private RegistroInmunologico registroInmunologico;

    @OneToOne(mappedBy = "paciente")
    private HistoriaClinica historiaClinica;
    @OneToOne
    @JoinColumn(name = "Usuario_id",referencedColumnName = "id")

    private Usuario usuario;
}
