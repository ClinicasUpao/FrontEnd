package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
@Table(name = "Pagos")
public class Pago {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "ha_pagado", nullable = false)
    private boolean pagado;
    @OneToOne
    @JoinColumn(name = "cita_id",nullable = false)
    private Cita cita;

}
