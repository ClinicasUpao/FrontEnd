package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Estado;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.TipoAtencion;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
@Table(name = "Intervalos")
public class Intervalo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "Tipo_Atencion", nullable = false)
    private TipoAtencion tipoAtencion;
    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    @Column(name = "hora_Inicio", nullable = false)
    private LocalDateTime horaInicio;
    @Column(name = "hora_Fin", nullable = false)
    private LocalDateTime horaFin;
    @Column(name = "maxCitas", nullable = false)
    private Long maxCitas;
    @Column(name = "duracion_citas", nullable = false)
    private Long duracionCita;

    @ManyToOne
    @JoinColumn(name = "medico_id")
    private Medico medico;

    @OneToMany(mappedBy = "intervalo", fetch = FetchType.LAZY)
    private List<Cita> citas;

    @PrePersist
    @PreUpdate
    private void validateHoras() {
        if (horaFin.isBefore(horaInicio)) {
            throw new IllegalArgumentException("La hora de fin no puede ser anterior a la hora de inicio.");
        }
    }

}

