package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "Vacunas")
public class Vacuna {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "dosis", nullable = false)
    private String dosis;
    @Column(name = "fecha_aplicacion", nullable = false)
    private String fechaAplicacion;
    @Column(name = "nombre", nullable = false)
    private String nombre;
    @ManyToOne
    @JoinColumn(name = "registroInmunologicoId", referencedColumnName = "registroInmunologicoId")
    private RegistroInmunologico registroInmunologico;

}
