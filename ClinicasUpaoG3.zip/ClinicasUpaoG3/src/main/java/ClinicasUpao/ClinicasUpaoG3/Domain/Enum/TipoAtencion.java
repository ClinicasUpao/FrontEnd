package ClinicasUpao.ClinicasUpaoG3.Domain.Enum;

public enum TipoAtencion {
    HOSPITAL,
    CLINICA
}
