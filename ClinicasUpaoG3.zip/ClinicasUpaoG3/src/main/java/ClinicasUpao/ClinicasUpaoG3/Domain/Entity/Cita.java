package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Estado;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Citas")
public class Cita {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(name = "estado", nullable = false)
    private Estado estado;

    @Column(name = "fechahora", nullable = false)
    private LocalDateTime fechaHora; // Este es el nombre correcto

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "medico_id", nullable = false)
    private Medico medico;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "paciente_id", nullable = false)
    private Paciente paciente;

    @Column(name = "asistencia", nullable = false)
    private boolean asistencia;

    private boolean cancelada;
    private String motivoCancelacion;
    private boolean recordatorioEnviado;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "intervalo_id", nullable = false)
    private Intervalo intervalo;
}
