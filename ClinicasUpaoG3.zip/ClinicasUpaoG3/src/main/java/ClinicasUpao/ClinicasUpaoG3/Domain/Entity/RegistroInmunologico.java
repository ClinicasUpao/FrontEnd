package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Data
@Table(name = "Registro_Inmunologico")
public class RegistroInmunologico {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "registroInmunologicoId")
    private Long registroInmunologicoId;
    @OneToOne
    @JoinColumn(name = "usuario_id", referencedColumnName = "id", nullable = false)
    private Paciente paciente;
    @OneToMany(mappedBy = "registroInmunologico", cascade = CascadeType.ALL)
    private List<Vacuna> vacunas;


}
