package ClinicasUpao.ClinicasUpaoG3.Domain.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
@Table(name = "Receta")
public class Receta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "recetaId")
    private Long recetaId;

    @ManyToOne
    @JoinColumn(name = "tratamiento_id", referencedColumnName = "id")
    private Tratamiento tratamiento;

    @OneToMany(mappedBy = "receta", cascade = CascadeType.ALL)
    private List<Dosis> dosis;
}
