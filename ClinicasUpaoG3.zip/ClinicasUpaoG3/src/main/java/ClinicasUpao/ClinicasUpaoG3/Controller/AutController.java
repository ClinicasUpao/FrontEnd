package ClinicasUpao.ClinicasUpaoG3.Controller;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.TokenRestablecimiento;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.ERole;
import ClinicasUpao.ClinicasUpaoG3.Dto.*;
import ClinicasUpao.ClinicasUpaoG3.Exception.BadRequestException;
import ClinicasUpao.ClinicasUpaoG3.Exception.MessageResponse;
import ClinicasUpao.ClinicasUpaoG3.Exception.RolNoEncontradoException;
import ClinicasUpao.ClinicasUpaoG3.Repository.PacienteRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.TokenRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.UsuarioRepository;
import ClinicasUpao.ClinicasUpaoG3.Security.TokenProvider;
import ClinicasUpao.ClinicasUpaoG3.Service.EmailService;
import ClinicasUpao.ClinicasUpaoG3.Service.UsuarioService;
import jakarta.mail.MessagingException;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AutController {
    private final UsuarioService usuarioService;
    private final TokenProvider tokenProvider;
    private final EmailService emailService;
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final TokenRepository tokenRepository;
    private final PacienteRepository pacienteRepository;


    private void sendVerificationEmail(UsuarioProfileDTO userProfile) throws MessagingException {
        String email = userProfile.getEmail();
        String nombreUsuario = userProfile.getNombre();
        String verificationLink = "https://clinicasupao.com/verify?token=" + userProfile.getVerificationToken();
        emailService.sendRegistrationSuccessEmail(email, nombreUsuario, verificationLink);
    }

    @PostMapping("/registro/paciente")
    public ResponseEntity<?> registropaciente(@Valid @RequestBody SignupRequestDTO signupRequestDTO) {
        try {

            if (signupRequestDTO.getFechaNacimiento().isAfter(LocalDate.now())) {
                return ResponseEntity.badRequest().body("La fecha de nacimiento no puede ser en el futuro.");
            }

            ERole rol = ERole.PACIENTE;
            UsuarioProfileDTO userProfile = usuarioService.registropaciente(signupRequestDTO, rol);
            sendVerificationEmail(userProfile);
            return new ResponseEntity<>(userProfile, HttpStatus.CREATED);
        } catch (RolNoEncontradoException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Rol no encontrado.");
        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al enviar el correo electrónico: " + e.getMessage());
        } catch (BadRequestException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Solicitud incorrecta: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error inesperado: " + e.getMessage());
        }
    }

    @PostMapping("/registro/medico")
    public ResponseEntity<?> registtromedico(@Valid @RequestBody SignupRequestMedicoDTO signupRequestMedicoDTO) {
        try {
            if (signupRequestMedicoDTO.getFechaNacimiento().isAfter(LocalDate.now())) {
                return ResponseEntity.badRequest().body("La fecha de nacimiento no puede ser en el futuro.");
            }
            if (signupRequestMedicoDTO.getDepartamento() == null || signupRequestMedicoDTO.getDepartamento().isEmpty()) {
                return ResponseEntity.badRequest().body("El departamento es obligatorio.");
            }
            if (signupRequestMedicoDTO.getDistrito() == null || signupRequestMedicoDTO.getDistrito().isEmpty()) {
                return ResponseEntity.badRequest().body("El distrito es obligatorio.");
            }
            if (signupRequestMedicoDTO.getDireccion() == null || signupRequestMedicoDTO.getDireccion().isEmpty()) {
                return ResponseEntity.badRequest().body("La dirección es obligatoria.");
            }
            if (signupRequestMedicoDTO.getEspecialidad() == null || signupRequestMedicoDTO.getEspecialidad().isEmpty()) {
                return ResponseEntity.badRequest().body("La especialidad es obligatoria.");
            }
            ERole rol = ERole.MEDICO;
            UsuarioProfileDTO userProfile = usuarioService.registerMedicoWithRole(signupRequestMedicoDTO, rol);
            sendVerificationEmail(userProfile);
            return new ResponseEntity<>(userProfile, HttpStatus.CREATED);
        } catch (RolNoEncontradoException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Rol no encontrado.");
        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al enviar el correo electrónico: " + e.getMessage());
        } catch (BadRequestException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Solicitud incorrecta: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error inesperado: " + e.getMessage());
        }
    }




    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginDTO loginDTO) {
        try {
            AuthResponseDTO authResponse = usuarioService.login(loginDTO);
            if (authResponse.getRole().equals("MEDICO")) {
                System.out.println("Inicio de sesión exitoso para el médico: " + loginDTO.getEmail());
            } else if (authResponse.getRole().equals("PACIENTE")) {
                System.out.println("Inicio de sesión exitoso para el paciente: " + loginDTO.getEmail());
            }

            return ResponseEntity.ok(authResponse);
        } catch (BadCredentialsException e) {
            System.out.println("Credenciales inválidas para el usuario: " + loginDTO.getEmail());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Credenciales inválidas.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error inesperado: " + e.getMessage());
        }
    }
    @CrossOrigin(origins = "http://127.0.0.1:5500")
    @PostMapping("/forgot-password")
    public ResponseEntity<?> forgotPassword(@RequestBody Map<String, String> request) {
        String email = request.get("email");

        if (email == null || email.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("El correo no puede estar vacío.");
        }
        if (!usuarioService.isEmailRegistered(email)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("No se encontró un usuario con este correo.");
        }
        String token = tokenProvider.createPasswordResetToken(email);
        String resetLink = "http://localhost:4200/reset-password?token=" + token;

        emailService.sendPasswordResetEmail(email, resetLink);
        return ResponseEntity.ok("Enlace de recuperación enviado al correo.");
    }
    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> request) throws BadRequestException, org.apache.coyote.BadRequestException {
        String newPassword = request.get("newPassword");
        String confirmPassword = request.get("confirmPassword");

        if (newPassword == null || newPassword.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("La nueva contraseña no puede estar vacía.");
        }
        if (!newPassword.equals(confirmPassword)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Las contraseñas no coinciden.");
        }
        String email = request.get("email");
        usuarioService.resetPassword(email, newPassword);
        return ResponseEntity.ok("Contraseña restablecida con éxito.");
    }
    @PostMapping("/configurar-contraseña")
    public ResponseEntity<MessageResponse> configurarContraseña(
            @RequestParam("token") String token,
            @RequestBody ContraseñaRequestDTO nuevaContraseñaDTO) {

        TokenRestablecimiento tokenRestablecimiento = tokenRepository.findByToken(token)
                .orElseThrow(() -> new RuntimeException("Token inválido o ha expirado"));

        if (tokenRestablecimiento.getExpiracion().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("El token ha expirado");
        }
        Paciente paciente = pacienteRepository.findById(tokenRestablecimiento.getPacienteId())
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));
        paciente.setContrasena(passwordEncoder.encode(nuevaContraseñaDTO.getNuevaContrasena()));
        pacienteRepository.save(paciente);
        tokenRepository.delete(tokenRestablecimiento);

        return new ResponseEntity<>(new MessageResponse("Contraseña configurada con éxito"), HttpStatus.OK);
    }




}