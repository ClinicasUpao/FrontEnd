package ClinicasUpao.ClinicasUpaoG3.Controller;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Cita;
import ClinicasUpao.ClinicasUpaoG3.Dto.CancelarCitaRequest;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaRequestDTO;
import ClinicasUpao.ClinicasUpaoG3.Exception.CitaCanceladaException;
import ClinicasUpao.ClinicasUpaoG3.Exception.CitasNotFoundException;
import ClinicasUpao.ClinicasUpaoG3.Exception.MessageResponse;
import ClinicasUpao.ClinicasUpaoG3.Repository.PacienteRepository;
import ClinicasUpao.ClinicasUpaoG3.Service.CitaService;
import ClinicasUpao.ClinicasUpaoG3.Service.PacienteService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;

@RestController
@RequestMapping("/paciente")
public class PacienteController {
    private final CitaService citaService;
    private final PacienteService pacienteService;


    public PacienteController(CitaService citaService, PacienteService pacienteService) {
        this.citaService = citaService;
        this.pacienteService = pacienteService;
    }


    @PreAuthorize("hasRole('PACIENTE')")
    @PostMapping("/{idPaciente}/cancelar-cita")
    public ResponseEntity<?> cancelarCita(@PathVariable String idPaciente, @RequestBody CancelarCitaRequest request) {
        try {
            citaService.cancelarCita(request.getIdCita(), request.getDocumentoIdentidad(), request.getMotivo());
            return ResponseEntity.ok("Cita cancelada exitosamente");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
        } catch (CitasNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al cancelar la cita.");
        }
    }
    @PostMapping("/citas")
    public ResponseEntity<Void> registrarCita(@RequestBody CitaRequestDTO citaDTO) {
        pacienteService.registrarCita(citaDTO);
        return ResponseEntity.ok().build();
    }

}












