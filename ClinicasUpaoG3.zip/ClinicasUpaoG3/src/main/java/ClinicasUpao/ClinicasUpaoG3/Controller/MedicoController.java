package ClinicasUpao.ClinicasUpaoG3.Controller;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Cita;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaDetallesDTO;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaRequestDTO;
import ClinicasUpao.ClinicasUpaoG3.Dto.IntervaloRequestDTO;
import ClinicasUpao.ClinicasUpaoG3.Dto.ReprogramarCitaDto;
import ClinicasUpao.ClinicasUpaoG3.Exception.CitasNotFoundException;
import ClinicasUpao.ClinicasUpaoG3.Exception.MessageResponse;
import ClinicasUpao.ClinicasUpaoG3.Exception.PacienteNotFoundException;
import ClinicasUpao.ClinicasUpaoG3.Service.CitaService;
import ClinicasUpao.ClinicasUpaoG3.Service.MedicoService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/medical")
public class MedicoController {
    private final MedicoService medicoService;
    private final CitaService citaService;
    private static final Logger logger = LoggerFactory.getLogger(MedicoController.class);

    public MedicoController(MedicoService medicoService, CitaService citaService) {
        this.medicoService = medicoService;
        this.citaService = citaService;
    }
    @CrossOrigin(origins = "http://127.0.0.1:5500")
    @PostMapping("/horario-trabajo")
    @PreAuthorize("hasRole('MEDICO')")
    public ResponseEntity<String> definirHorarioTrabajo(@RequestBody IntervaloRequestDTO intervaloDTO) {
        try {
            medicoService.definirHorarioTrabajo(intervaloDTO);
            return ResponseEntity.status(HttpStatus.CREATED).build(); // Responde con 201 Created
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage()); // Responde con 409 Conflict
        } catch (NullPointerException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error: uno o más campos son nulos.");
        } catch (Exception e) {
            e.printStackTrace(); // Esto mostrará más información en los logs
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error interno del servidor: " + e.getMessage()); // Mensaje con detalles
        }
    }
    @PostMapping("/citas")
    @PreAuthorize("hasRole('MEDICO')")
    public ResponseEntity<MessageResponse> registrarCita(@RequestBody CitaRequestDTO citaDTO) {
        try {
            logger.info("Intentando registrar una nueva cita para el paciente con ID: {}", citaDTO.getDocumentoIdentidad());
            medicoService.registrarCita(citaDTO);
            logger.info("Cita registrada exitosamente para el paciente con ID: {}", citaDTO.getDocumentoIdentidad());
            return new ResponseEntity<>(new MessageResponse("Cita registrada con éxito"), HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error al registrar la cita: {}", e.getMessage());
            return new ResponseEntity<>(new MessageResponse("Error al registrar la cita: " + e.getMessage()), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/citas/paciente/{documentoIdentidad}")
    @PreAuthorize("hasRole('MEDICO')")
    public ResponseEntity<List<CitaDetallesDTO>> obtenerCitasPorDniPaciente(@PathVariable String documentoIdentidad) {
        if (documentoIdentidad == null || documentoIdentidad.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        }

        try {
            List<CitaDetallesDTO> citas = citaService.obtenerCitasPorDocumentoIdentidad(documentoIdentidad);
            if (citas.isEmpty()) {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(null);
            }
            return ResponseEntity.ok(citas);
        } catch (PacienteNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null);
        } catch (CitasNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(null);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(null);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(null);
        }
    }
    @PreAuthorize("hasRole('ROLE_MEDICO')")
    @PostMapping("/asistencia")
    public ResponseEntity<Cita> registrarAsistencia(
            @RequestParam("documentoIdentidad") String documentoIdentidad,
            @RequestParam("asistencia") boolean asistencia) {
        Cita cita = citaService.registrarAsistencia(documentoIdentidad, asistencia);
        return ResponseEntity.ok(cita);
    }
    @PreAuthorize("hasRole('ROLE_MEDICO')")
    @PutMapping("/reprogramar")
    public ResponseEntity<String> reprogramarCita(@Valid @RequestBody ReprogramarCitaDto reprogramarCitaDto) {
        try {
            medicoService.reprogramarCita(
                    reprogramarCitaDto.getCitaId(),
                    reprogramarCitaDto.getNuevaFechaHora(),
                    reprogramarCitaDto.getDocumentoIdentidad()
            );
            return ResponseEntity.ok("Cita reprogramada con éxito.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al reprogramar la cita: " + e.getMessage());
        }
    }
    @PutMapping("/actualizar")
    public Medico actualizarInformacionMedica(@AuthenticationPrincipal Medico medicoAutenticado,
                                              @Valid @RequestBody Medico medicoActualizado) {
        if (!medicoAutenticado.getId().equals(medicoActualizado.getId())) {
            throw new RuntimeException("No tienes permiso para actualizar esta información");
        }
        if (medicoActualizado.getEspecialidad() == null || medicoActualizado.getEspecialidad().isEmpty()) {
            throw new RuntimeException("La especialidad es un campo requerido.");
        }
        if (medicoActualizado.getColegiatura() == null || medicoActualizado.getColegiatura().isEmpty()) {
            throw new RuntimeException("La colegiatura es un campo requerido.");
        }
        if (medicoActualizado.getFacultadEgreso() == null || medicoActualizado.getFacultadEgreso().isEmpty()) {
            throw new RuntimeException("La facultad de egreso es un campo requerido.");
        }
        if (medicoActualizado.getEmail() != null && !isValidEmail(medicoActualizado.getEmail())) {
            throw new RuntimeException("El formato del correo electrónico es inválido.");
        }
        if (medicoActualizado.getSubespecialidad() != null && !medicoActualizado.getSubespecialidad().isEmpty() &&
                (medicoActualizado.getSubespecialidadLicencia() == null || medicoActualizado.getSubespecialidadLicencia().isEmpty())) {
            throw new RuntimeException("Si se especifica una subespecialidad, debe incluir su licencia.");
        }
        return medicoService.actualizarInformacionMedica(medicoActualizado);
    }
    private boolean isValidEmail(String email) {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

}



