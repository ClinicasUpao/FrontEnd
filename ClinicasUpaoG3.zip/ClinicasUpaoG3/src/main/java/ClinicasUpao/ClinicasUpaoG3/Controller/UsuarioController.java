package ClinicasUpao.ClinicasUpaoG3.Controller;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import ClinicasUpao.ClinicasUpaoG3.Repository.MedicoRepository;
import ClinicasUpao.ClinicasUpaoG3.Service.MedicoService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/clinicasUpao")
public class UsuarioController {

    private final MedicoRepository medicoRepository;
    private final MedicoService medicoService;

    public UsuarioController(MedicoRepository medicoRepository, MedicoService medicoService) {
        this.medicoRepository = medicoRepository;
        this.medicoService = medicoService;
    }

    @GetMapping("/buscar")
    public ResponseEntity<List<Medico>> buscarMedicos(
            @RequestParam(required = false) String nombre,
            @RequestParam(required = false) String apellido,
            @RequestParam(required = false) String colegiatura) {

        List<Medico> medicos = medicoService.buscarMedicos(colegiatura, nombre, apellido);

        if (medicos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        medicos.forEach(medico -> {
            medico.setCitas(null);
            medico.setUsuario(null);
        });
        return ResponseEntity.ok(medicos);
    }
    @GetMapping("/buscar-colegiatura")
    public ResponseEntity<Medico> buscarMedicoPorColegiatura(@RequestParam String colegiatura) {
        return medicoService.buscarPorColegiatura(colegiatura)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
