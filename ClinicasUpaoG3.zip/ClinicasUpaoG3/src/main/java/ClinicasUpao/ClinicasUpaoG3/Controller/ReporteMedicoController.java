package ClinicasUpao.ClinicasUpaoG3.Controller;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Cita;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Estado;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaDetallesDTO;
import ClinicasUpao.ClinicasUpaoG3.Service.CitaService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/reporte")
public class ReporteMedicoController {
    private final CitaService citaService;

    public ReporteMedicoController(CitaService citaService ) {
        this.citaService = citaService;
    }
    @PreAuthorize("hasRole('MEDICO')")
    @GetMapping("/medico/rangoFechas/{medicoId}")
    public ResponseEntity<List<CitaDetallesDTO>> obtenerCitasPorRangoDeFechasYMedico(
            @PathVariable Long medicoId,
            @RequestParam LocalDateTime inicio,
            @RequestParam LocalDateTime fin) {
        List<Cita> citas = citaService.obtenerCitasPorRangoDeFechasYMedico(medicoId, inicio, fin);
        List<CitaDetallesDTO> citaDetallesDTOs = citas.stream()
                .map(cita -> new CitaDetallesDTO(
                        cita.getId(),
                        cita.getFechaHora(),
                        cita.getPaciente().getNombre(),
                        cita.getPaciente().getApellido(),
                        cita.getMotivoCancelacion(),
                        cita.getEstado().name()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(citaDetallesDTOs);
    }
    @PreAuthorize("hasRole('MEDICO')")
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<CitaDetallesDTO>> obtenerCitasPorEstado(@PathVariable Estado estado) {
        List<Cita> citas = citaService.obtenerCitasPorEstado(estado);
        List<CitaDetallesDTO> citaDetallesDTOs = citas.stream()
                .map(cita -> new CitaDetallesDTO(
                        cita.getId(),
                        cita.getFechaHora(),
                        cita.getPaciente().getNombre(),
                        cita.getPaciente().getApellido(),
                        cita.getMotivoCancelacion(),
                        cita.getEstado().name()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(citaDetallesDTOs);
    }
    @PreAuthorize("hasRole('MEDICO')")
    @GetMapping("/medico/{medicoId}/anio/{anio}/estado/{estado}")
    public ResponseEntity<List<CitaDetallesDTO>> obtenerCitasPorAnioYEstado(
            @PathVariable Long medicoId,
            @PathVariable int anio,
            @PathVariable Estado estado) {
        List<Cita> citas = citaService.obtenerCitasPorAnioYEstado(medicoId, anio, estado);
        List<CitaDetallesDTO> citaDetallesDTOs = citas.stream()
                .map(cita -> new CitaDetallesDTO(
                        cita.getId(),
                        cita.getFechaHora(),
                        cita.getPaciente().getNombre(),
                        cita.getPaciente().getApellido(),
                        cita.getMotivoCancelacion(),
                        cita.getEstado().name()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(citaDetallesDTOs);
    }
    @PreAuthorize("hasRole('MEDICO')")
    @GetMapping("/paciente/{pacienteId}/anio/{anio}")
    public ResponseEntity<List<CitaDetallesDTO>> obtenerCitasPorPacienteYAnio(
            @PathVariable Long pacienteId,
            @PathVariable int anio) {
        List<Cita> citas = citaService.obtenerCitasPorPacienteYAnio(pacienteId, anio);
        List<CitaDetallesDTO> citaDetallesDTOs = citas.stream()
                .map(cita -> new CitaDetallesDTO(
                        cita.getId(),
                        cita.getFechaHora(),
                        cita.getPaciente().getNombre(),
                        cita.getPaciente().getApellido(),
                        cita.getMotivoCancelacion(),
                        cita.getEstado().name()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(citaDetallesDTOs);
    }
    @PreAuthorize("hasRole('MEDICO')")
    @GetMapping("/medico/{medicoId}/fecha")
    public ResponseEntity<List<CitaDetallesDTO>> obtenerCitasPorMedicoYFecha(
            @PathVariable Long medicoId,
            @RequestParam LocalDate fecha) {
        List<Cita> citas = citaService.obtenerCitasPorMedicoYFecha(medicoId, fecha);
        List<CitaDetallesDTO> citaDetallesDTOs = citas.stream()
                .map(cita -> new CitaDetallesDTO(
                        cita.getId(),
                        cita.getFechaHora(),
                        cita.getPaciente().getNombre(),
                        cita.getPaciente().getApellido(),
                        cita.getMotivoCancelacion(),
                        cita.getEstado().name()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(citaDetallesDTOs);
    }
    @GetMapping("/por-mes")
    public ResponseEntity<List<CitaDetallesDTO>> obtenerCitasPorMes(
            @RequestParam int mes,
            @RequestParam int anio) {
        List<CitaDetallesDTO> citas = citaService.obtenerCitasPorMes(mes, anio);
        return ResponseEntity.ok(citas);
    }
    @PreAuthorize("hasRole('MEDICO')")
    @GetMapping("/medico/{medicoId}/fecha/{fecha}")
    public ResponseEntity<List<CitaDetallesDTO>> obtenerCitasPorMedicoYDia(
            @PathVariable Long medicoId,
            @PathVariable LocalDate fecha) {
        List<Cita> citas = citaService.obtenerCitasPorMedicoYDia(medicoId, fecha);
        List<CitaDetallesDTO> citaDetallesDTOs = citas.stream()
                .map(cita -> new CitaDetallesDTO(
                        cita.getId(),
                        cita.getFechaHora(),
                        cita.getPaciente().getNombre(),
                        cita.getPaciente().getApellido(),
                        cita.getMotivoCancelacion(),
                        cita.getEstado().name()
                ))
                .collect(Collectors.toList());
        return ResponseEntity.ok(citaDetallesDTOs);
    }
}


