package ClinicasUpao.ClinicasUpaoG3.Exception;

public class PacienteNotFoundException extends RuntimeException {
    public PacienteNotFoundException(String message) {
        super(message);
    }
}