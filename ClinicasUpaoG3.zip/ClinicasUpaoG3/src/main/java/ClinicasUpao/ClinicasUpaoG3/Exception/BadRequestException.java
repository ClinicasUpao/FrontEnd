package ClinicasUpao.ClinicasUpaoG3.Exception;

public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) {
        super(message);
    }
}
