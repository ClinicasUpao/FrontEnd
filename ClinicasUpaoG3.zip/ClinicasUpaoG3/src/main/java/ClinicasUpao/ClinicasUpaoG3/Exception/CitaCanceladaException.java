package ClinicasUpao.ClinicasUpaoG3.Exception;

public class CitaCanceladaException extends RuntimeException {
    public CitaCanceladaException(String message) {
        super(message);
    }
}
