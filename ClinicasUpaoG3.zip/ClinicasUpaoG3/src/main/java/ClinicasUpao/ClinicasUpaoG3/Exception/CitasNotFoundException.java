package ClinicasUpao.ClinicasUpaoG3.Exception;

public class CitasNotFoundException extends RuntimeException {
    public CitasNotFoundException(String message) {
        super(message);
    }
}
