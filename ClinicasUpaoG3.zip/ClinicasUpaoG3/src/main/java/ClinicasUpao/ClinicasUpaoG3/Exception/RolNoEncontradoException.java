package ClinicasUpao.ClinicasUpaoG3.Exception;

public class RolNoEncontradoException extends RuntimeException {
    public RolNoEncontradoException(String message) {
        super(message);
    }
}