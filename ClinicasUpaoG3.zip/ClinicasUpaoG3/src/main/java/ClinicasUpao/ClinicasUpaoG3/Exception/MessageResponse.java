package ClinicasUpao.ClinicasUpaoG3.Exception;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class MessageResponse  {
    private String message;



}
