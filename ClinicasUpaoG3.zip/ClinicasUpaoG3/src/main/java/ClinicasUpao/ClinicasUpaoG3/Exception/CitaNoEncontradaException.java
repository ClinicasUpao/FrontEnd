package ClinicasUpao.ClinicasUpaoG3.Exception;

public class CitaNoEncontradaException extends RuntimeException {
    public CitaNoEncontradaException(String message) {
        super(message);
    }
}
