package ClinicasUpao.ClinicasUpaoG3.Service.impl;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.*;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Estado;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaRequestDTO;
import ClinicasUpao.ClinicasUpaoG3.Dto.IntervaloRequestDTO;
import ClinicasUpao.ClinicasUpaoG3.Exception.CitasNotFoundException;
import ClinicasUpao.ClinicasUpaoG3.Repository.*;
import ClinicasUpao.ClinicasUpaoG3.Security.TokenProvider;
import ClinicasUpao.ClinicasUpaoG3.Service.EmailService;
import ClinicasUpao.ClinicasUpaoG3.Service.MedicoService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class MedicoServiceImpl implements MedicoService {

    private final IntervaloRepository intervaloRepository;
    private final CitaRepository citaRepository;
    private final MedicoRepository medicoRepository;
    private final PacienteRepository pacienteRepository;
    private final TokenProvider tokenProvider;
    private final EmailService emailService;
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final TokenRepository tokenRepository;

    @Value("${jwt.secret}")
    private String secretKey;

    @Transactional
    public void definirHorarioTrabajo(IntervaloRequestDTO intervaloDTO) {
        if (intervaloDTO.getHoraInicio() == null || intervaloDTO.getHoraFin() == null) {
            throw new IllegalArgumentException("Las horas de inicio y fin son obligatorias.");
        }
        Medico medico = obtenerMedicoAutenticado();
        LocalDateTime fechaInicio = intervaloDTO.getHoraInicio();
        LocalDateTime fechaFin = intervaloDTO.getHoraFin();
        Optional<Intervalo> intervaloOpt = intervaloRepository.findByMedicoAndFechaAndHoraInicioBeforeAndHoraFinAfter(
                medico.getId(),
                fechaInicio.toLocalDate(),
                fechaInicio,
                fechaFin
        );
        if (intervaloOpt.isPresent()) {
            throw new IllegalArgumentException("Ya existe un intervalo que se solapa en esta fecha y hora.");
        }
        Intervalo intervalo = new Intervalo();
        intervalo.setMedico(medico);
        intervalo.setTipoAtencion(intervaloDTO.getTipoAtencion());
        intervalo.setHoraInicio(fechaInicio);
        intervalo.setHoraFin(fechaFin);
        intervalo.setMaxCitas(intervaloDTO.getMaxCitas());
        intervalo.setDuracionCita(intervaloDTO.getDuracionCita());
        intervalo.setFecha(fechaInicio.toLocalDate());
        intervaloRepository.save(intervalo);
    }
    @Transactional
    public void registrarCita(CitaRequestDTO citaDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String correoMedico = authentication.getName();
        Medico medico = usuarioRepository.findByEmail(correoMedico)
                .orElseThrow(() -> new RuntimeException("Médico no encontrado")).getMedico();
        LocalDateTime fechaHoraCita = citaDTO.getFechaInicio();

        Intervalo intervalo = intervaloRepository.findFirstByMedicoAndFechaAndHoraInicioBeforeAndHoraFinAfter(
                medico.getId(),
                fechaHoraCita.toLocalDate(),
                fechaHoraCita,
                fechaHoraCita.plusMinutes(15)
        ).orElseThrow(() -> new RuntimeException("Intervalo de trabajo no definido o no único"));

        LocalDateTime fechaFinCita = fechaHoraCita.plusMinutes(intervalo.getDuracionCita());
        if (fechaHoraCita.isBefore(intervalo.getHoraInicio()) || fechaFinCita.isAfter(intervalo.getHoraFin())) {
            throw new RuntimeException("La cita no está dentro del horario de trabajo");
        }

        List<Cita> citasExistentes = citaRepository.findByMedicoAndFechaHoraBetween(
                medico, fechaHoraCita.toLocalDate().atStartOfDay(), fechaHoraCita.toLocalDate().atTime(23, 59));

        boolean haySuperposicion = citasExistentes.stream()
                .filter(cita -> !cita.isCancelada())
                .anyMatch(cita -> {
                    LocalDateTime citaFin = cita.getFechaHora().plusMinutes(intervalo.getDuracionCita());
                    return !(fechaFinCita.isBefore(cita.getFechaHora()) || fechaHoraCita.isAfter(citaFin));
                });

        if (haySuperposicion) {
            throw new RuntimeException("La cita se solapa con otra cita existente.");
        }
        Paciente paciente = pacienteRepository.findByDocumentoIdentidad(citaDTO.getDocumentoIdentidad())
                .orElseGet(() -> {
                    String contrasenaTemporal = generarContrasenaTemporal();
                    Paciente nuevoPaciente = Paciente.builder()
                            .nombre(citaDTO.getNombre())
                            .apellido(citaDTO.getApellido())
                            .email(citaDTO.getEmail())
                            .telefono(citaDTO.getTelefono())
                            .documentoIdentidad(citaDTO.getDocumentoIdentidad())
                            .contrasena(passwordEncoder.encode(contrasenaTemporal))
                            .build();
                    Paciente pacienteCreado = pacienteRepository.save(nuevoPaciente);
                    enviarCorreoBienvenida(pacienteCreado, contrasenaTemporal);
                    return pacienteCreado;
                });
        if (!paciente.getNombre().equals(citaDTO.getNombre()) || !paciente.getApellido().equals(citaDTO.getApellido())) {
            throw new RuntimeException("Los datos del paciente no coinciden.");
        }

        Cita nuevaCita = Cita.builder()
                .paciente(paciente)
                .medico(medico)
                .fechaHora(fechaHoraCita)
                .estado(Estado.PENDIENTE)
                .intervalo(intervalo)
                .build();

        citaRepository.save(nuevaCita);
        String correoPaciente = paciente.getEmail();
        String subject = "Confirmación de Cita Médica";
        String body = String.format("Estimado/a %s %s, su cita ha sido registrada exitosamente para el día %s a las %s con el Dr. %s.",
                paciente.getNombre(),
                paciente.getApellido(),
                fechaHoraCita.toLocalDate(),
                fechaHoraCita.toLocalTime(),
                medico.getNombre());
        emailService.sendEmail(correoPaciente, subject, body);
    }
    public void enviarCorreoBienvenida(Paciente paciente, String contrasenaTemporal) {
        String subject = "Bienvenido/a al sistema de Clínicas UPAO";
        String body = String.format(
                "Estimado/a %s %s, su usuario ha sido creado exitosamente. " +
                        "Su contraseña temporal es: %s. Por favor, configure una nueva contraseña en el siguiente enlace: " +
                        "<a href=\"https://tusistema.com/configurar-contraseña?token=%s\">Configurar contraseña</a>",
                paciente.getNombre(),
                paciente.getApellido(),
                contrasenaTemporal,
                generarTokenRestablecimiento(Long.valueOf(paciente.getId())) // Método para generar el token
        );

        emailService.sendEmail(paciente.getEmail(), subject, body);
    }
    public String generarContrasenaTemporal() {
        return UUID.randomUUID().toString().substring(0, 8);
    }
    public String generarTokenRestablecimiento(Long pacienteId) {
        String token = UUID.randomUUID().toString();
        LocalDateTime expiracion = LocalDateTime.now().plusHours(24);

        TokenRestablecimiento tokenRestablecimiento = new TokenRestablecimiento();
        tokenRestablecimiento.setToken(token);
        tokenRestablecimiento.setPacienteId(pacienteId);
        tokenRestablecimiento.setExpiracion(expiracion);

        tokenRepository.save(tokenRestablecimiento);

        return token;
    }
    @Transactional
    public Medico obtenerMedicoAutenticado() {
        String token = extractJwtToken();
        String email = extractEmailFromToken(token);
        return medicoRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Médico no autenticado"));
    }

    private String extractJwtToken() {
        String authorizationHeader = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
                .getRequest().getHeader("Authorization");
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            return authorizationHeader.substring(7);
        } else {
            throw new RuntimeException("Token JWT no encontrado en la cabecera");
        }
    }
    public String extractEmailFromToken(String token) {
        Claims claims = Jwts.parser()
                .setSigningKey(secretKey)
                .parseClaimsJws(token)
                .getBody();
        return claims.getSubject();
    }
    @Transactional
    public void reprogramarCita(Long citaId, LocalDateTime nuevaFechaHora, String documentoIdentidad) {
        Cita cita = citaRepository.findById(citaId)
                .orElseThrow(() -> new CitasNotFoundException("Cita no encontrada con el ID: " + citaId));

        Medico medico = obtenerMedicoAutenticado();
        if (!cita.getMedico().equals(medico)) {
            throw new IllegalArgumentException("No está autorizado para reprogramar esta cita.");
        }
        Intervalo intervalo = intervaloRepository.findFirstByMedicoAndFechaAndHoraInicioBeforeAndHoraFinAfter(
                medico.getId(),
                nuevaFechaHora.toLocalDate(),
                nuevaFechaHora,
                nuevaFechaHora.plusMinutes(15)
        ).orElseThrow(() -> new RuntimeException("Intervalo de trabajo no definido o no único"));
        LocalDateTime fechaFinCita = nuevaFechaHora.plusMinutes(intervalo.getDuracionCita());
        if (nuevaFechaHora.isBefore(intervalo.getHoraInicio()) || fechaFinCita.isAfter(intervalo.getHoraFin())) {
            throw new RuntimeException("La nueva fecha y hora de la cita no están dentro del horario de trabajo del médico.");
        }
        List<Cita> citasExistentes = citaRepository.findByMedicoAndFechaHoraBetween(
                medico, nuevaFechaHora.toLocalDate().atStartOfDay(), nuevaFechaHora.toLocalDate().atTime(23, 59));
        boolean haySuperposicion = citasExistentes.stream().filter(citaExistente -> !citaExistente.getEstado().equals(Estado.CANCELADA)).anyMatch(citaExistente ->
                !(fechaFinCita.isBefore(citaExistente.getFechaHora()) ||
                        nuevaFechaHora.isAfter(citaExistente.getFechaHora().plusMinutes(intervalo.getDuracionCita()))));
        if (haySuperposicion) {
            throw new RuntimeException("La nueva cita se solapa con otra cita existente.");
        }
        cita.setFechaHora(nuevaFechaHora);
        cita.setEstado(Estado.REPROGRAMADA);
        citaRepository.save(cita);
        notificarPacienteReprogramacion(cita, nuevaFechaHora);
        habilitarHorario(cita);
    }

    private void notificarPacienteReprogramacion(Cita cita, LocalDateTime nuevaFechaHora) {
        Paciente paciente = cita.getPaciente();
        String subject = "Reprogramación de Cita";
        String body = String.format("Estimado/a %s,\n\nSu cita ha sido reprogramada para el %s a las %s.\n" +
                        "Gracias por su comprensión.",
                paciente.getNombre(),
                nuevaFechaHora.toLocalDate(),
                nuevaFechaHora.toLocalTime());

        emailService.sendEmail(paciente.getEmail(), subject, body);
    }

    private void habilitarHorario(Cita cita) {
        LocalDateTime fechaHoraCita = cita.getFechaHora();
        Medico medico = cita.getMedico();


        Intervalo intervalo = intervaloRepository.findFirstByMedicoAndFechaAndHoraInicioBeforeAndHoraFinAfter(
                medico.getId(),
                fechaHoraCita.toLocalDate(),
                fechaHoraCita,
                fechaHoraCita.plusMinutes(15)
        ).orElseThrow(() -> new RuntimeException("No se encontró un intervalo válido para el médico."));
    }
    @Override
    public Medico actualizarInformacionMedica(Medico medico) {
        Medico medicoExistente = medicoRepository.findById(medico.getId())
                .orElseThrow(() -> new RuntimeException("Médico no encontrado"));
        medicoExistente.setEspecialidad(medico.getEspecialidad());
        medicoExistente.setEspecialidadLicencia(medico.getEspecialidadLicencia());
        medicoExistente.setFacultadEgreso(medico.getFacultadEgreso());
        medicoExistente.setSubespecialidad(medico.getSubespecialidad());
        medicoExistente.setSubespecialidadLicencia(medico.getSubespecialidadLicencia());
        return medicoRepository.save(medicoExistente);
    }
    @Override
    public List<Medico> buscarMedicos(String colegiatura, String nombre, String apellido) {
        return medicoRepository.buscarMedicos(colegiatura, nombre, apellido);
    }
    public Optional<Medico> buscarPorColegiatura(String colegiatura) {
        return medicoRepository.findByColegiatura(colegiatura);
    }

    }


