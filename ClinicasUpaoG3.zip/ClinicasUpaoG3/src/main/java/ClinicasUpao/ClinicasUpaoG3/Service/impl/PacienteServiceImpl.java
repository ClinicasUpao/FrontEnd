package ClinicasUpao.ClinicasUpaoG3.Service.impl;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Cita;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Intervalo;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Estado;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaRequestDTO;
import ClinicasUpao.ClinicasUpaoG3.Repository.CitaRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.IntervaloRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.MedicoRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.PacienteRepository;
import ClinicasUpao.ClinicasUpaoG3.Service.EmailService;
import ClinicasUpao.ClinicasUpaoG3.Service.PacienteService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@RequiredArgsConstructor
@Service
public class PacienteServiceImpl implements PacienteService {
    private final PacienteRepository pacienteRepository;
    private final MedicoRepository medicoRepository;
    private final IntervaloRepository intervaloRepository;
    private final CitaRepository citaRepository;
    private final EmailService emailService;

    @Override
    @Transactional
    public void registrarCita(CitaRequestDTO citaDTO) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String emailPaciente = authentication.getName();
        Paciente paciente = pacienteRepository.findByEmail(emailPaciente)
                .orElseThrow(() -> new RuntimeException("Paciente no encontrado"));

        LocalDateTime fechaHoraCita = citaDTO.getFechaInicio();

        if (fechaHoraCita == null) {
            throw new IllegalArgumentException("La fecha de inicio de la cita no puede ser nula");
        }
        Medico medico = medicoRepository.findById(citaDTO.getMedicoId())
                .orElseThrow(() -> new RuntimeException("Médico no encontrado con ID: " + citaDTO.getMedicoId()));
        Intervalo intervalo = intervaloRepository.findFirstByMedicoAndFechaAndHoraInicioBeforeAndHoraFinAfter(
                medico.getId(),
                fechaHoraCita.toLocalDate(),
                fechaHoraCita,
                fechaHoraCita.plusMinutes(15)
        ).orElseThrow(() -> new RuntimeException("Intervalo de trabajo no definido o no único"));

        LocalDateTime fechaFinCita = fechaHoraCita.plusMinutes(intervalo.getDuracionCita());

        if (fechaHoraCita.isBefore(intervalo.getHoraInicio()) || fechaFinCita.isAfter(intervalo.getHoraFin())) {
            throw new RuntimeException("La cita no está dentro del horario de trabajo");
        }

        List<Cita> citasExistentes = citaRepository.findByPacienteAndFechaHoraBetween(
                paciente,
                fechaHoraCita.toLocalDate().atStartOfDay(),
                fechaHoraCita.toLocalDate().atTime(23, 59)
        );

        if (citasExistentes.size() >= 3) {
            throw new RuntimeException("El paciente ya tiene 3 citas programadas para el día " + fechaHoraCita.toLocalDate());
        }

        boolean haySuperposicion = citasExistentes.stream()
                .filter(cita -> !cita.isCancelada())
                .anyMatch(cita -> {
                    LocalDateTime citaFin = cita.getFechaHora().plusMinutes(intervalo.getDuracionCita());
                    return !(fechaFinCita.isBefore(cita.getFechaHora()) || fechaHoraCita.isAfter(citaFin));
                });

        if (haySuperposicion) {
            throw new RuntimeException("Ya hay una cita registrada en este horario");
        }
        Cita nuevaCita = Cita.builder()
                .paciente(paciente)
                .medico(medico)
                .fechaHora(fechaHoraCita)
                .estado(Estado.PENDIENTE)
                .intervalo(intervalo)
                .asistencia(false)
                .cancelada(false)
                .recordatorioEnviado(false)
                .build();

        citaRepository.save(nuevaCita);
        String subject = "Confirmación de Cita Médica";
        String body = String.format("Estimado/a %s %s, su cita ha sido registrada exitosamente para el día %s a las %s con el Dr. %s.",
                paciente.getNombre(),
                paciente.getApellido(),
                fechaHoraCita.toLocalDate(),
                fechaHoraCita.toLocalTime(),
                medico.getNombre());
        emailService.sendEmail(paciente.getEmail(), subject, body);
    }
}