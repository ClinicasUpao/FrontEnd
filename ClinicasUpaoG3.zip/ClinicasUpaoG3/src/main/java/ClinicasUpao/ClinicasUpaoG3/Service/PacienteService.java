package ClinicasUpao.ClinicasUpaoG3.Service;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Cita;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaRequestDTO;

import java.util.List;

public interface PacienteService {
    void registrarCita(CitaRequestDTO citaDTO);

}
