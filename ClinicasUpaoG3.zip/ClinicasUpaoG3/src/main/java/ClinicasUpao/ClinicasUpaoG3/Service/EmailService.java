package ClinicasUpao.ClinicasUpaoG3.Service;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailService implements IEmailService {

    @Autowired
    private JavaMailSender emailSender;


    public void sendVerificationEmail(String to, String verificationLink) {
        String subject = "Tu enlace de acceso";
        String body = "Haz clic en el siguiente enlace para acceder: " + verificationLink;

        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);

        emailSender.send(message);
    }

    public void sendPasswordResetEmail(String email, String resetLink) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(email);
        message.setSubject("Recuperación de Contraseña");
        message.setText("Para restablecer tu contraseña, por favor sigue el siguiente enlace: " + resetLink);

        emailSender.send(message);
    }

    public void sendSimpleMessage(String to, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);

        emailSender.send(message);
    }

    public void sendEmail(String to, String subject, String body) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        emailSender.send(message);
    }


    public void sendRegistrationSuccessEmail(String to, String nombreUsuario, String verificationLink) throws MessagingException {
        String subject = "Bienvenido a Clinicas UPAO";

        // HTML del correo de bienvenida
        String body = "<!DOCTYPE html>"
                + "<html lang='es'>"
                + "<head>"
                + "<meta charset='UTF-8'>"
                + "<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
                + "<title>Correo de Bienvenida</title>"
                + "<style>"
                + "body {"
                + "    font-family: 'Arial', sans-serif;"
                + "    background-color: #e9f5f1;"
                + "    margin: 0;"
                + "    padding: 0;"
                + "    color: #333;"
                + "}"
                + ".container {"
                + "    max-width: 600px;"
                + "    margin: 40px auto;"
                + "    background-color: #ffffff;"
                + "    padding: 30px;"
                + "    border-radius: 15px;"
                + "    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);"
                + "}"
                + ".header {"
                + "    background-color: #2D5D98;"
                + "    color: white;"
                + "    padding: 20px;"
                + "    border-top-left-radius: 15px;"
                + "    border-top-right-radius: 15px;"
                + "    text-align: center;"
                + "}"
                + ".header h1 {"
                + "    margin: 0;"
                + "    font-size: 28px;"
                + "}"
                + ".header p {"
                + "    margin: 10px 0 0;"
                + "    font-size: 16px;"
                + "}"
                + "h2 {"
                + "    color: #2D5D98;"
                + "    font-size: 24px;"
                + "    text-align: center;"
                + "    margin: 20px 0;"
                + "}"
                + "p {"
                + "    color: #555555;"
                + "    font-size: 16px;"
                + "    line-height: 1.6;"
                + "    margin: 10px 0;"
                + "}"
                + ".highlight {"
                + "    background-color: #f9f9f9;"
                + "    padding: 15px;"
                + "    border-left: 5px solid #2D5D98;"
                + "    margin: 20px 0;"
                + "    border-radius: 5px;"
                + "}"
                + ".button {"
                + "    display: inline-block;"
                + "    background-color: #2D5D98;"
                + "    color: white;"
                + "    padding: 12px 30px;"
                + "    text-decoration: none;"
                + "    border-radius: 5px;"
                + "    margin-top: 20px;"
                + "    font-weight: bold;"
                + "    transition: background-color 0.3s, transform 0.3s;"
                + "    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);"
                + "}"
                + ".button:hover {"
                + "    background-color: #1a4d77;"
                + "    transform: translateY(-2px);"
                + "}"
                + ".footer {"
                + "    text-align: center;"
                + "    margin-top: 30px;"
                + "    font-size: 14px;"
                + "    color: #999999;"
                + "    border-top: 1px solid #dddddd;"
                + "    padding-top: 20px;"
                + "}"
                + ".social-icons {"
                + "    text-align: center;"
                + "    margin-top: 20px;"
                + "}"
                + ".social-icons img {"
                + "    width: 40px;"
                + "    margin: 0 15px;"
                + "    transition: transform 0.3s;"
                + "}"
                + ".social-icons img:hover {"
                + "    transform: scale(1.1);"
                + "}"
                + ".footer p {"
                + "    margin: 5px 0;"
                + "}"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<div class='container'>"
                + "<div class='header'>"
                + "<h1>¡Bienvenido a ClinicasUpao!</h1>"
                + "<p>Hola, " + nombreUsuario + ".</p>"
                + "</div>"
                + "<h2>Estamos emocionados de tenerte con nosotros</h2>"
                + "<div class='highlight'>"
                + "<p>Tu cuenta ha sido creada exitosamente.</p>"
                + "<p>Ahora puedes acceder a la plataforma y comenzar a explorar todos nuestros servicios y funciones de salud.</p>"
                + "</div>"
                + "<p>Si tienes alguna duda o necesitas asistencia, no dudes en contactarnos.</p>"
                + "<p>Haz clic en el botón de abajo para confirmar tu cuenta:</p>"
                + "<a href='" + verificationLink + "' class='button'>Confirmar Cuenta</a>"
                + "<div class='footer'>"
                + "<p>Conéctate con nosotros:</p>"
                + "<div class='social-icons'>"
                + "<a href='https://facebook.com'><img src='https://img.icons8.com/ios-filled/50/4CAF50/facebook-new.png' alt='Facebook'/></a>"
                + "<a href='https://twitter.com'><img src='https://img.icons8.com/ios-filled/50/4CAF50/twitter-squared.png' alt='Twitter'/></a>"
                + "<a href='https://instagram.com'><img src='https://img.icons8.com/ios-filled/50/4CAF50/instagram-new.png' alt='Instagram'/></a>"
                + "</div>"
                + "<p>© 2024 ClinicasUpao. Todos los derechos reservados.</p>"
                + "</div>"
                + "</div>"
                + "</body>"
                + "</html>";


        MimeMessage message = emailSender.createMimeMessage();
        MimeMessageHelper helper = new MimeMessageHelper(message, true);
        helper.setTo(to);
        helper.setSubject(subject);
        helper.setText(body, true);

        emailSender.send(message);
    }
    public void enviarRecordatorio(String to, String subject, String text) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);
        emailSender.send(message);
    }
    public void enviarCorreoConfiguracionContraseña(Paciente paciente, String token) {
        String subject = "Configura tu contraseña";
        String body = String.format(
                "Estimado/a %s %s, para configurar tu contraseña, por favor haz clic en el siguiente enlace: " +
                        "<a href=\"https://tusistema.com/configurar-contraseña?token=%s\">Configurar contraseña</a>. Este enlace es válido por 24 horas.",
                paciente.getNombre(),
                paciente.getApellido(),
                token
        );

        try {
            MimeMessage message = emailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(paciente.getEmail());
            helper.setSubject(subject);
            helper.setText(body, true);

            emailSender.send(message);
        } catch (MessagingException e) {
            throw new RuntimeException("Error al enviar el correo de configuración de contraseña: " + e.getMessage());
        }
    }
}
