package ClinicasUpao.ClinicasUpaoG3.Service;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaRequestDTO;
import ClinicasUpao.ClinicasUpaoG3.Dto.IntervaloRequestDTO;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface MedicoService {
    void definirHorarioTrabajo(IntervaloRequestDTO intervaloDTO);
    void registrarCita(CitaRequestDTO citaDTO);
    void reprogramarCita(Long citaId, LocalDateTime nuevaFechaHora, String documentoIdentidad);
    List<Medico> buscarMedicos(String colegiatura, String nombre, String apellido);
    Optional<Medico> buscarPorColegiatura(String colegiatura);
    Medico actualizarInformacionMedica(Medico medico);
}
