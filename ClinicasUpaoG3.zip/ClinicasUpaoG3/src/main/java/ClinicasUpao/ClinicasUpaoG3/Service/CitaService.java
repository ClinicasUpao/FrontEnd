package ClinicasUpao.ClinicasUpaoG3.Service;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Cita;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Estado;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaDetallesDTO;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface CitaService {

    // Obtener citas por documento de identidad del paciente
    List<CitaDetallesDTO> obtenerCitasPorDocumentoIdentidad(String documentoIdentidad);
    // Registrar asistencia a una cita
    Cita registrarAsistencia(String documentoIdentidad, boolean asistencia);
    // Cancelar una cita
    void cancelarCita(Long citaId, String documentoIdentidad, String motivo);
    // Enviar recordatorios de citas programadas
    void enviarRecordatorios();
    // Obtener citas de un médico en una fecha específica
    List<Cita> obtenerCitasPorMedicoYFecha(Long medicoId, LocalDate fecha);
    // Obtener citas de un médico en un rango de fechas
    List<Cita> obtenerCitasPorRangoDeFechasYMedico(Long medicoId, LocalDateTime inicio, LocalDateTime fin);
    // Obtener citas por estado
    List<Cita> obtenerCitasPorEstado(Estado estado);

    // Obtener citas por año y estado
    List<Cita> obtenerCitasPorAnioYEstado(Long medicoId, int anio, Estado estado);
    // Obtener citas de un paciente por año
    List<Cita> obtenerCitasPorPacienteYAnio(Long pacienteId, int anio);;
    List<CitaDetallesDTO> obtenerCitasPorMes(int mes, int anio);
    List<Cita> obtenerCitasPorMedicoYDia(Long medicoId, LocalDate fecha);


}
