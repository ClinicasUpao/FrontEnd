package ClinicasUpao.ClinicasUpaoG3.Service.impl;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Cita;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Intervalo;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Estado;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaDetallesDTO;
import ClinicasUpao.ClinicasUpaoG3.Dto.CitaRequestDTO;
import ClinicasUpao.ClinicasUpaoG3.Dto.ReporteCitasDTO;
import ClinicasUpao.ClinicasUpaoG3.Exception.*;
import ClinicasUpao.ClinicasUpaoG3.Repository.CitaRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.IntervaloRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.MedicoRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.PacienteRepository;
import ClinicasUpao.ClinicasUpaoG3.Service.CitaService;
import ClinicasUpao.ClinicasUpaoG3.Service.EmailService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CitaServiceImpl implements CitaService {
    private static final Logger logger = LoggerFactory.getLogger(CitaServiceImpl.class);

    private final CitaRepository citaRepository;
    private final PacienteRepository pacienteRepository;
    private final EmailService emailService;
    private final IntervaloRepository intervaloRepository;
    private final MedicoRepository medicoRepository;

    // Constructor
    public CitaServiceImpl(CitaRepository citaRepository, PacienteRepository pacienteRepository, EmailService emailService, IntervaloRepository intervaloRepository, MedicoRepository medicoRepository) {
        this.citaRepository = citaRepository;
        this.pacienteRepository = pacienteRepository;
        this.emailService = emailService;
        this.intervaloRepository = intervaloRepository;
        this.medicoRepository = medicoRepository;
    }

    // Método para obtener citas por documento de identidad
    @Transactional(readOnly = true)
    public List<CitaDetallesDTO> obtenerCitasPorDocumentoIdentidad(String documentoIdentidad) {
        if (documentoIdentidad == null || documentoIdentidad.isEmpty()) {
            throw new IllegalArgumentException("El documento de identidad no puede ser nulo o vacío.");
        }

        Paciente paciente = pacienteRepository.findByDocumentoIdentidad(documentoIdentidad)
                .orElseThrow(() -> new PacienteNotFoundException("Paciente no encontrado con el documento de identidad proporcionado"));

        List<Cita> citas = citaRepository.findByPaciente(paciente);

        if (citas.isEmpty()) {
            throw new CitasNotFoundException("No se encontraron citas para el paciente con documento de identidad: " + documentoIdentidad);
        }

        return citas.stream()
                .map(cita -> {
                    CitaDetallesDTO detalles = new CitaDetallesDTO();
                    detalles.setId(cita.getId());
                    detalles.setFechaHora(cita.getFechaHora());
                    detalles.setNombrePaciente(cita.getPaciente().getNombre());
                    detalles.setApellidoPaciente(cita.getPaciente().getApellido());
                    return detalles;
                })
                .collect(Collectors.toList());
    }

    // Método para registrar asistencia
    @Transactional
    public Cita registrarAsistencia(String documentoIdentidad, boolean asistencia) {
        // Buscar al paciente
        Paciente paciente = pacienteRepository.findByDocumentoIdentidad(documentoIdentidad)
                .orElseThrow(() -> new PacienteNotFoundException("Paciente no encontrado con el documento de identidad proporcionado"));

        LocalDateTime fechaActual = LocalDateTime.now();
        LocalDateTime inicioDelDia = fechaActual.toLocalDate().atStartOfDay();
        LocalDateTime finDelDia = inicioDelDia.plusDays(1);
        List<Cita> citasHoy = citaRepository.findByPacienteAndFechaHoraBetween(paciente, inicioDelDia, finDelDia);
        if (citasHoy.isEmpty()) {
            throw new CitasNotFoundException("No hay citas programadas para hoy para el paciente con documento de identidad: " + documentoIdentidad);
        }

        Cita cita = citasHoy.get(0);
        if (cita.isAsistencia() == asistencia) {
            throw new IllegalArgumentException("La asistencia ya está marcada como " + asistencia + " para esta cita.");
        }
        cita.setAsistencia(asistencia);
        if (asistencia) {
            cita.setEstado(Estado.REALIZADA);
        }
        citaRepository.save(cita);
        return cita;
    }
    @Override
    @Transactional
    public void cancelarCita(Long citaId, String documentoIdentidad, String motivo) {
        Cita cita = citaRepository.findById(citaId)
                .orElseThrow(() -> new CitasNotFoundException("Cita no encontrada con el ID: " + citaId));
        if (!cita.getPaciente().getDocumentoIdentidad().equals(documentoIdentidad)) {
            throw new IllegalArgumentException("No está autorizado para cancelar esta cita.");
        }
        if (cita.isCancelada()) {
            throw new CitaCanceladaException("La cita ya ha sido cancelada.");
        }
        cita.setCancelada(true);
        cita.setMotivoCancelacion(motivo);
        citaRepository.save(cita);
        cita.setEstado(Estado.CANCELADA);

        notificarPaciente(cita);
        notificarMedico(cita, motivo);
        habilitarHorario(cita);
    }

    private void habilitarHorario(Cita cita) {
        LocalDateTime fechaHoraCita = cita.getFechaHora();
        Medico medico = cita.getMedico();


        Intervalo intervalo = intervaloRepository.findFirstByMedicoAndFechaAndHoraInicioBeforeAndHoraFinAfter(
                medico.getId(),
                fechaHoraCita.toLocalDate(),
                fechaHoraCita,
                fechaHoraCita.plusMinutes(15)
        ).orElseThrow(() -> new RuntimeException("No se encontró un intervalo válido para el médico."));
    }
    private void notificarPaciente(Cita cita) {
        Paciente paciente = cita.getPaciente();
        String subject = "Cancelación de Cita";
        String body = "Estimado/a " + paciente.getNombre() + ",\n\n" +
                "Su cita programada para el " + cita.getFechaHora() + " ha sido cancelada.\n" +
                "Gracias por su comprensión.";
        emailService.sendEmail(paciente.getEmail(), subject, body);
    }

    private void notificarMedico(Cita cita, String motivo) {
        String subject = "Cancelación de Cita del Paciente";
        String body = "Estimado/a " + cita.getMedico().getNombre() + ",\n\n" +
                "La cita programada con el paciente " + cita.getPaciente().getNombre() + " ha sido cancelada.\n" +
                "Motivo de la cancelación: " + motivo + "\n\n" +
                "Gracias por su comprensión.";
        emailService.sendEmail(cita.getMedico().getEmail(), subject, body);
    }

    @Override
    @Scheduled(fixedRate = 3600000)
    public void enviarRecordatorios() {
        LocalDateTime ahora = LocalDateTime.now();
        LocalDateTime limite = ahora.plusHours(12);

        List<Cita> citasProximas = citaRepository.findByFechaHoraBetween(ahora, limite);

        for (Cita cita : citasProximas) {
            if (!cita.isRecordatorioEnviado()) {
                try {
                    String subject = "Recordatorio de Cita Médica";
                    String body = String.format("Estimado/a %s, le recordamos que tiene una cita programada para el %s.",
                            cita.getPaciente().getNombre(), cita.getFechaHora());

                    emailService.sendEmail(cita.getPaciente().getEmail(), subject, body);

                    cita.setRecordatorioEnviado(true);
                    citaRepository.save(cita);
                } catch (Exception e) {

                    System.err.println("Error enviando recordatorio para la cita " + cita.getId() + ": " + e.getMessage());
                }
            }
        }
    }


    @Override
    public List<Cita> obtenerCitasPorMedicoYFecha(Long medicoId, LocalDate fecha) {
        Medico medico = medicoRepository.findById(medicoId)
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con el ID: " + medicoId));
        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(23, 59, 59);
        List<Cita> citas = citaRepository.findByMedicoIdAndFechaHoraBetween(medicoId, inicio, fin);
        if (citas.isEmpty()) {
            throw new ResourceNotFoundException("No se encontraron citas para el médico en la fecha proporcionada.");
        }

        return citas;
    }
    @Override
    public List<Cita> obtenerCitasPorRangoDeFechasYMedico(Long medicoId, LocalDateTime inicio, LocalDateTime fin) {
        Medico medico = medicoRepository.findById(medicoId)
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con el ID: " + medicoId));
        if (inicio.isAfter(fin)) {
            throw new IllegalArgumentException("La fecha de inicio no puede ser después de la fecha de fin.");
        }
        List<Cita> citas = citaRepository.findByMedicoIdAndFechaHoraBetween(medicoId, inicio, fin);
        if (citas.isEmpty()) {
            throw new ResourceNotFoundException("No se encontraron citas para el médico en el rango de fechas proporcionado.");
        }

        return citas;
    }
@Override
public List<Cita> obtenerCitasPorEstado(Estado estado) {

    return citaRepository.findByEstado(estado);
}

@Override
public List<CitaDetallesDTO> obtenerCitasPorMes(int mes, int anio) {
    if (mes < 1 || mes > 12) {
        throw new IllegalArgumentException("El mes debe estar entre 1 y 12.");
    }
    if (anio < 1900 || anio > LocalDate.now().getYear()) {
        throw new IllegalArgumentException("El año debe ser mayor a 1900 y menor o igual al año actual.");
    }

    LocalDate inicio = LocalDate.of(anio, mes, 1);
    LocalDate fin = inicio.plusMonths(1).minusDays(1);
    List<Cita> citas = citaRepository.findAllByFechaHoraBetween(inicio.atStartOfDay(), fin.atTime(23, 59, 59));

    return citas.stream()
            .map(cita -> new CitaDetallesDTO(
                    cita.getId(),
                    cita.getFechaHora(),
                    cita.getPaciente().getNombre(),
                    cita.getPaciente().getApellido(),
                    cita.getMotivoCancelacion(),
                    cita.getEstado().name()
            ))
            .collect(Collectors.toList());
}
@Override
    public List<Cita> obtenerCitasPorMedicoYDia(Long medicoId, LocalDate fecha) {

        Medico medico = medicoRepository.findById(medicoId)
                .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con el ID: " + medicoId));

        LocalDateTime inicio = fecha.atStartOfDay();
        LocalDateTime fin = fecha.atTime(23, 59, 59);

        List<Cita> citas = citaRepository.findByMedicoIdAndFechaHoraBetween(medicoId, inicio, fin);

        if (citas.isEmpty()) {
            throw new ResourceNotFoundException("No se encontraron citas para el médico en la fecha proporcionada.");
        }

        return citas;
    }
@Override
public List<Cita> obtenerCitasPorAnioYEstado(Long medicoId, int anio, Estado estado) {
    Medico medico = medicoRepository.findById(medicoId)
            .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con el ID: " + medicoId));

    return citaRepository.findByMedicoIdAndAnioAndEstado(medicoId, anio, estado);
}
@Override
public List<Cita> obtenerCitasPorPacienteYAnio(Long pacienteId, int anio) {
    Paciente paciente = pacienteRepository.findById(pacienteId)
            .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con el ID: " + pacienteId));

    return citaRepository.findByPacienteIdAndAnio(pacienteId, anio);
}

}

