package ClinicasUpao.ClinicasUpaoG3.Service;

import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.ERole;
import ClinicasUpao.ClinicasUpaoG3.Dto.*;
import org.apache.coyote.BadRequestException;

import javax.management.relation.RoleNotFoundException;

public interface UsuarioService {
    UsuarioProfileDTO registropaciente(SignupRequestDTO signupRequestDTO, ERole roleEnum) throws BadRequestException;

    UsuarioProfileDTO registerMedicoWithRole(SignupRequestMedicoDTO signupRequestMedicoDTO, ERole roleEnum) throws BadRequestException;

    AuthResponseDTO login(LoginDTO loginDTO);

    boolean isEmailRegistered(String email);

    void resetPassword(String correo, String newContrasena) throws BadRequestException;

    String findEmailById(Long id);

}
