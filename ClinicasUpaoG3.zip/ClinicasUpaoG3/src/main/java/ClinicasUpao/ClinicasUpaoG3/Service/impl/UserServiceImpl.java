package ClinicasUpao.ClinicasUpaoG3.Service.impl;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Role;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Usuario;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.ERole;
import ClinicasUpao.ClinicasUpaoG3.Dto.*;
import ClinicasUpao.ClinicasUpaoG3.Exception.InvalidCredentialsException;
import ClinicasUpao.ClinicasUpaoG3.Mapper.UserMapper;
import ClinicasUpao.ClinicasUpaoG3.Repository.MedicoRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.PacienteRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.RolRepository;
import ClinicasUpao.ClinicasUpaoG3.Repository.UsuarioRepository;
import ClinicasUpao.ClinicasUpaoG3.Security.TokenProvider;
import ClinicasUpao.ClinicasUpaoG3.Service.UsuarioService;
import lombok.RequiredArgsConstructor;
import org.apache.coyote.BadRequestException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.management.relation.RoleNotFoundException;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor

public class UserServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final PacienteRepository pacienteRepository;
    private final MedicoRepository medicoRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;
    private final UserMapper userMapper;
    private final AuthenticationManager authenticationManager;
    private final TokenProvider tokenProvider;

    @Transactional
    public UsuarioProfileDTO registropaciente(SignupRequestDTO signupRequestDTO, ERole roleEnum) throws BadRequestException {
        boolean emailExists = usuarioRepository.existsByEmail(signupRequestDTO.getEmail());
        boolean existsAsPaciente = pacienteRepository.existsByNombreAndApellido(signupRequestDTO.getNombre(), signupRequestDTO.getApellido());

        if (emailExists) {
            throw new UsernameNotFoundException("El correo electrónico ya está registrado");
        }
        if (existsAsPaciente) {
            throw new BadRequestException("Ya existe un paciente con el mismo nombre y apellido");
        }

        Role role;
        try {
            role = rolRepository.findByName(roleEnum)
                    .orElseThrow(() -> new RoleNotFoundException("Rol no encontrado"));
        } catch (RoleNotFoundException e) {
            throw new BadRequestException("Error al encontrar el rol: " + e.getMessage());
        }

        signupRequestDTO.setContrasena(passwordEncoder.encode(signupRequestDTO.getContrasena()));
        Usuario usuario = userMapper.toUserEntity(signupRequestDTO);
        usuario.setRole(role);

        System.out.println("SignupRequestDTO: " + signupRequestDTO);
        Paciente paciente = new Paciente();
        paciente.setUsuario(usuario);
        paciente.setNombre(signupRequestDTO.getNombre());
        paciente.setApellido(signupRequestDTO.getApellido());
        paciente.setEmail(signupRequestDTO.getEmail());
        paciente.setContrasena(signupRequestDTO.getContrasena());
        paciente.setTelefono(signupRequestDTO.getDocumentoIdentidad());
        paciente.setFechaNacimiento(signupRequestDTO.getFechaNacimiento());
        paciente.setGenero(signupRequestDTO.getGenero());
        paciente.setPaisOrigen(signupRequestDTO.getPaisOrigen());
        paciente.setDepartamento(signupRequestDTO.getDepartamento());
        paciente.setDistrito(signupRequestDTO.getDistrito());
        paciente.setDireccion(signupRequestDTO.getDireccion());
        paciente.setTipoDocumento(signupRequestDTO.getTipoDocumento());
        paciente.setCreated_at(LocalDateTime.now());
        paciente.setUpdated_at(LocalDateTime.now());
        paciente.setDocumentoIdentidad(signupRequestDTO.getDocumentoIdentidad());

        paciente = pacienteRepository.save(paciente);
        usuario.setPaciente(paciente);

        Usuario savedUser = usuarioRepository.save(usuario);
        return userMapper.toUserProfileDTO(savedUser);
    }
    @Transactional
    public UsuarioProfileDTO registerMedicoWithRole(SignupRequestMedicoDTO signupRequestMedicoDTO, ERole roleEnum) throws BadRequestException {
        boolean emailExists = usuarioRepository.existsByEmail(signupRequestMedicoDTO.getEmail());
        boolean existsAsMedico = medicoRepository.existsByNombreAndApellido(signupRequestMedicoDTO.getNombre(), signupRequestMedicoDTO.getApellido());
        if (emailExists) {
            throw new UsernameNotFoundException("El correo electrónico ya está registrado");
        }
        if (existsAsMedico) {
            throw new BadRequestException("Ya existe un médico con el mismo nombre y apellido");
        }

        Role role;
        try {
            role = rolRepository.findByName(roleEnum)
                    .orElseThrow(() -> new RoleNotFoundException("Rol no encontrado"));
        } catch (RoleNotFoundException e) {
            throw new BadRequestException("Error al encontrar el rol: " + e.getMessage());
        }

        signupRequestMedicoDTO.setContrasena(passwordEncoder.encode(signupRequestMedicoDTO.getContrasena()));
        Usuario usuario = userMapper.toUserEntity(signupRequestMedicoDTO);
        usuario.setRole(role);

        Medico medico = new Medico();
        medico.setNombre(signupRequestMedicoDTO.getNombre());
        medico.setApellido(signupRequestMedicoDTO.getApellido());
        medico.setEmail(signupRequestMedicoDTO.getEmail());
        medico.setContrasena(signupRequestMedicoDTO.getContrasena());
        medico.setTelefono(signupRequestMedicoDTO.getDocumentoIdentidad());
        medico.setFechaNacimiento(signupRequestMedicoDTO.getFechaNacimiento());
        medico.setPaisOrigen(signupRequestMedicoDTO.getPaisOrigen());
        medico.setDepartamento(signupRequestMedicoDTO.getDepartamento());
        medico.setDistrito(signupRequestMedicoDTO.getDistrito());
        medico.setDireccion(signupRequestMedicoDTO.getDireccion());
        medico.setColegiatura(signupRequestMedicoDTO.getColegiatura());
        medico.setEspecialidad(signupRequestMedicoDTO.getEspecialidad());
        medico.setRegistroEspecialidad(signupRequestMedicoDTO.getRegistroEspecialidad());
        medico.setGenero(signupRequestMedicoDTO.getGenero());
        medico.setTipoDocumento(signupRequestMedicoDTO.getTipoDocumento());
        medico.setDocumentoIdentidad(signupRequestMedicoDTO.getDocumentoIdentidad());

        medico.setUsuario(usuario);

        medico = medicoRepository.save(medico);
        usuario.setMedico(medico);

        Usuario savedUser = usuarioRepository.save(usuario);
        return userMapper.toUserProfileDTO(savedUser);
    }

    @Transactional
    @Override
    public AuthResponseDTO login(LoginDTO loginDTO) {
        Usuario usuario = usuarioRepository.findByEmail(loginDTO.getEmail())
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado con el email " + loginDTO.getEmail()));

        if (!passwordEncoder.matches(loginDTO.getContrasena(), usuario.getContrasena())) {
            throw new InvalidCredentialsException("Credenciales incorrectas");
        }

        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(loginDTO.getEmail(), loginDTO.getContrasena())
        );

        String token = tokenProvider.createAccessToken(authentication);
        AuthResponseDTO response = userMapper.toAuthResponseDTO(usuario, token);
        return response;
    }
    public boolean isEmailRegistered(String email) {
        return usuarioRepository.findByEmail(email).isPresent();
    }
    @Transactional
    public void resetPassword(String correo, String newContrasena) throws BadRequestException {
        Usuario usuario = usuarioRepository.findByEmail(correo)
                .orElseThrow(() -> new BadRequestException("Usuario no encontrado."));

        usuario.setContrasena(passwordEncoder.encode(newContrasena));
        usuarioRepository.save(usuario);
    }
    @Override
    public String findEmailById(Long id) {
        Usuario user = usuarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario con ID " + id + " no encontrado"));
        return user.getEmail();
    }
}
