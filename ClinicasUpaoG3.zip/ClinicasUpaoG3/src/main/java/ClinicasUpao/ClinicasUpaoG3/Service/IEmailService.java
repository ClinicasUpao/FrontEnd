package ClinicasUpao.ClinicasUpaoG3.Service;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import jakarta.mail.MessagingException;

public interface IEmailService {
    void sendVerificationEmail(String to, String verificationLink);
    void sendPasswordResetEmail(String email, String resetLink);
    void sendRegistrationSuccessEmail(String email, String nombreUsuario, String verificationLink) throws MessagingException;
    void enviarCorreoConfiguracionContraseña(Paciente paciente, String token) throws MessagingException;
}
