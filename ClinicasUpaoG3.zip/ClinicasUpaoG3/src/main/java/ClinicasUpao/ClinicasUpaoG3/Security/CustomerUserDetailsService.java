package ClinicasUpao.ClinicasUpaoG3.Security;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Usuario;
import ClinicasUpao.ClinicasUpaoG3.Repository.UsuarioRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomerUserDetailsService implements UserDetailsService {
    private final UsuarioRepository usuarioRepository;

    public CustomerUserDetailsService(UsuarioRepository usuarioRepository) {
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Usuario usuario = usuarioRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("Usuario no encontrado con el email: " + username));

        return UsuarioPrincipal.create(usuario);
    }
}
