package ClinicasUpao.ClinicasUpaoG3.Dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;
@Data
public class ReprogramarCitaDto {
    @NotNull(message = "El ID de la cita es obligatorio.")
    private Long citaId;
    @NotNull(message = "La nueva fecha y hora son obligatorias.")
    private LocalDateTime nuevaFechaHora;
    @NotNull(message = "El documento de identidad es obligatorio.")
    private String documentoIdentidad;
}
