package ClinicasUpao.ClinicasUpaoG3.Dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class CitaRequestDTO {
    @NotNull(message = "La fecha de inicio de la cita es obligatoria")
    private LocalDateTime fechaInicio;

    @NotNull(message = "El nombre del paciente es obligatorio")
    private String nombre;

    @NotNull(message = "El apellido del paciente es obligatorio")
    private String apellido;

    @NotNull(message = "El email del paciente es obligatorio")
    @Email(message = "El email debe tener un formato válido")
    private String email;

    @NotNull(message = "El teléfono del paciente es obligatorio")
    @Pattern(regexp = "\\d{9}", message = "El teléfono debe tener 10 dígitos")
    private String telefono;

    @NotNull(message = "El DNI del paciente es obligatorio")
    @Pattern(regexp = "\\d{8}", message = "El DNI debe tener 8 dígitos")
    private String documentoIdentidad;
    private Long medicoId;
    private String motivoCita;
    private Integer duracionDeseada;
}
