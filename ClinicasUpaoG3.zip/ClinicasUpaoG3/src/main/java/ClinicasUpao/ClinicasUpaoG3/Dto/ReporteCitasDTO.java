package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.Data;

import java.util.List;

@Data
public class ReporteCitasDTO {
        private String nombreMedico;
        private String especialidad;
        private int totalPacientes;
        private double promedioDiario;
        private double promedioMensual;
        private List<CitaDetallesDTO> citas;
    }


