package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.Data;

@Data
public class ContraseñaRequestDTO {
    private String nuevaContrasena;
}