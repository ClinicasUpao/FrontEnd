package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.Data;

@Data
public class AuthResponseDTO {
    private String token;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private String direccion;
    private String genero;
    private String role;
}
