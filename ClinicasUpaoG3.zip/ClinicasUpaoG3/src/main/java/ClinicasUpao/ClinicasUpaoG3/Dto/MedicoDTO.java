package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.Data;

import java.util.Date;
@Data
public class MedicoDTO {
    private Long id;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private Date fechaNacimiento;
    private String colegiatura;
    private String especialidad;
}
