package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CitaDetallesDTO {
    private Long id;
    private LocalDateTime fechaHora;
    private String nombrePaciente;
    private String apellidoPaciente;
    private String motivo;
    private String estado;

    // Método para obtener la fecha en formato legible
    public String getFechaInicioFormateada() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        return fechaHora.format(formatter);
    }
}
