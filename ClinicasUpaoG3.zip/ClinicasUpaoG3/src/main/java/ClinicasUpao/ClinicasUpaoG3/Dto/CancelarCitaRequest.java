package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.Data;

@Data
public class CancelarCitaRequest {
    private Long IdCita;
    private String motivo;
    private String documentoIdentidad;
}
