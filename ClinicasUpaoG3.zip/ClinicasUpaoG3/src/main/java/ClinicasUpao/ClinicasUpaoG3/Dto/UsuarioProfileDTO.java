package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.Data;

import java.time.LocalDate;

@Data
public class UsuarioProfileDTO {
    private Integer id;
    private String nombre;
    private String apellido;
    private String email;
    private String telefono;
    private LocalDate fechaNacimiento;
    private String genero;
    private String departamento;
    private String distrito;
    private String direccion;
    private String documentoIdentidad;
    private String colegiatura; // medico
    private String verificationToken;

}
