package ClinicasUpao.ClinicasUpaoG3.Dto;

import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.TipoAtencion;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
public class IntervaloRequestDTO {
    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fecha;

    @NotNull(message = "El tipo de atención es obligatorio")
    private TipoAtencion tipoAtencion;

    @NotNull(message = "La hora de inicio es obligatoria")
    @FutureOrPresent(message = "La hora de inicio debe ser en el futuro o el presente")
    private LocalDateTime horaInicio;

    @NotNull(message = "La hora de fin es obligatoria")
    private LocalDateTime horaFin;

    @NotNull(message = "El número máximo de citas es obligatorio")
    @Positive(message = "El número máximo de citas debe ser un número positivo")
    private Long maxCitas;

    @NotNull(message = "La duración de las citas es obligatoria")
    @Positive(message = "La duración de las citas debe ser un número positivo")
    private Long duracionCita;
}
