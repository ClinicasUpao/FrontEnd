package ClinicasUpao.ClinicasUpaoG3.Dto;

import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Genero;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class SignupRequestPacienteDTO extends SignupRequestDTO{





}
