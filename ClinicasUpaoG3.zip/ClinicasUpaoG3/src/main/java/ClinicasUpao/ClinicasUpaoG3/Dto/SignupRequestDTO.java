package ClinicasUpao.ClinicasUpaoG3.Dto;

import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Genero;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.TipoDocumento;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class SignupRequestDTO {

    @NotBlank(message = "El nombre del paciente es obligatorio")
    @Size(min = 3, max = 20, message = "El nombre del paciente debe tener entre 3 y 20 caracteres")
    private String nombre;

    @NotBlank(message = "El apellido es obligatorio.")
    private String apellido;

    @NotBlank(message = "El correo electrónico es obligatorio")
    @Email(message = "El formato del correo electrónico no es válido")
    private String email;

    @NotEmpty(message = "La contraseña es obligatoria")
    @Size(min = 8, message = "La contraseña debe contener al menos 8 caracteres")
    private String contrasena;

    @NotNull(message = "La fecha de nacimiento es obligatoria")
    private LocalDate fechaNacimiento;

    @NotNull(message = "El género es obligatorio")
    private Genero genero;

    @NotBlank(message = "El país de origen es obligatorio")
    private String paisOrigen;

    @NotBlank(message = "El departamento es obligatorio")
    private String departamento;

    @NotBlank(message = "El distrito es obligatorio")
    private String distrito;

    @NotBlank(message = "La dirección es obligatoria")
    private String direccion;

    @NotBlank(message = "El documento de identidad es obligatorio")
    private String documentoIdentidad;

    @NotNull(message = "El tipo de documento es obligatorio")
    private TipoDocumento tipoDocumento;
}
