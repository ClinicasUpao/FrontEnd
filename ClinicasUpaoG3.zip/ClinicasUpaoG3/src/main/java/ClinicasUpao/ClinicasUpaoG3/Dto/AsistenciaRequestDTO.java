package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.Data;

@Data
public class AsistenciaRequestDTO {
    private String documentoIdentidad;
    private boolean asistencia;
}
