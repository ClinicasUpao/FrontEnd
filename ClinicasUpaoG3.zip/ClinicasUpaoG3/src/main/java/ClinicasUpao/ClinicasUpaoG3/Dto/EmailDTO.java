package ClinicasUpao.ClinicasUpaoG3.Dto;

import lombok.Data;

@Data
public class EmailDTO {
    private String destinatario;
    private String asunto;
    private String mensaje;
}
