package ClinicasUpao.ClinicasUpaoG3.Config;

import ClinicasUpao.ClinicasUpaoG3.Security.JWTConfigurer;
import ClinicasUpao.ClinicasUpaoG3.Security.JWTFilter;
import ClinicasUpao.ClinicasUpaoG3.Security.JwtAuthenticationEntryPoint;
import ClinicasUpao.ClinicasUpaoG3.Security.TokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.cors.CorsConfigurationSource;

import java.util.Arrays;
import java.util.List;

@Configuration
@RequiredArgsConstructor
@EnableWebSecurity
@EnableMethodSecurity
public class WebSecurityConfig {

    private final TokenProvider tokenProvider;
    private final JWTFilter jwtFilter;
    private final JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
    private final UserDetailsService userDetailsService;



    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .cors() // Permitir CORS
                .and()
                .csrf().disable() // Deshabilitar CSRF para APIs REST
                .authorizeHttpRequests(authz -> authz
                        .requestMatchers("/auth/login").permitAll()
                        .requestMatchers("/auth/registro/paciente").permitAll()
                        .requestMatchers("/auth/registro/medico").permitAll()
                        .requestMatchers("/auth/forgot-password").permitAll()
                        .requestMatchers("/auth/reset-password").permitAll()
                        .requestMatchers("/medical/**").permitAll()
                        .requestMatchers("/medical/horario-trabajo").permitAll()
                        .requestMatchers("/medical/citas").hasRole("MEDICO")
                        .requestMatchers("/medical/citas/paciente/{documentoIdentidad}").hasRole("MEDICO")
                        .requestMatchers("/medical/asistencia").hasRole("MEDICO")
                        .requestMatchers("/{idPaciente}/cancelar-cita").hasRole("PACIENTE")
                        .requestMatchers("/medical/reprogramar").hasRole("MEDICO")
                        .requestMatchers("/clinicasUpao/buscar").permitAll()
                        .requestMatchers("/clinicasUpao/buscar_colegiatura").permitAll()
                        .requestMatchers("/reporte/medico/rangoFechas").hasRole("MEDICO")
                        .requestMatchers("/reporte/estado/{estado}").hasRole("MEDICO")
                        .requestMatchers("/reporte/medico/{medicoId}/mes/{mes}/anio/{anio}/estado/{estado}").hasRole("MEDICO")
                        .requestMatchers("/reporte/medico/{medicoId}/anio/{anio}/estado/{estado}").hasRole("MEDICO")
                        .requestMatchers("/reporte/paciente/{pacienteId}/anio/{anio}").hasRole("MEDICO")
                        .requestMatchers("/reporte/medico/{medicoId}/rangoFechas").hasRole("MEDICO")
                        .requestMatchers("/reporte/por-mes").hasRole("MEDICO")
                        .requestMatchers("/medical/actualizar").hasRole("MEDICO")
                        .requestMatchers("/medico/{medicoId}/fecha/{fecha}").hasRole("MEDICO")
                        .requestMatchers("/paciente/citas").hasRole("PACIENTE")
                        .anyRequest().permitAll())
                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .logout(logout -> logout
                        .logoutSuccessUrl("/login?logout=true")
                        .permitAll())
                .apply(new JWTConfigurer(tokenProvider));

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("http://127.0.0.1:5500")); // Incluye ambos
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
        configuration.setAllowedHeaders(Arrays.asList("Authorization", "Content-Type"));
        configuration.setAllowCredentials(true); // Permitir credenciales
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authenticationConfiguration) throws Exception {
        return authenticationConfiguration.getAuthenticationManager();
    }

}
