package ClinicasUpao.ClinicasUpaoG3.Repository;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface MedicoRepository extends JpaRepository<Medico, Long> {
    boolean existsByNombreAndApellido(String nombre, String apellido);
    Optional<Medico> findByEmail(String email);
    @Query("SELECT m FROM Medico m WHERE "
            + "(:colegiatura IS NULL OR CAST(m.colegiatura AS string) = :colegiatura) "
            + "AND (:nombre IS NULL OR m.nombre ILIKE CONCAT('%', :nombre, '%')) "
            + "AND (:apellido IS NULL OR m.apellido ILIKE CONCAT('%', :apellido, '%'))")
    List<Medico> buscarMedicos(
            @Param("colegiatura") String colegiatura,
            @Param("nombre") String nombre,
            @Param("apellido") String apellido
    );
    Optional<Medico> findByColegiatura(String colegiatura);
    Optional<Medico> findByNombreAndApellido(String nombre, String apellido);





}





