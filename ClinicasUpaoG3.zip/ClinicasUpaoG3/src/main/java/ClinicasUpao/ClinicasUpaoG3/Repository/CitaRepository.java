package ClinicasUpao.ClinicasUpaoG3.Repository;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Cita;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import ClinicasUpao.ClinicasUpaoG3.Domain.Enum.Estado;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
@Repository
public interface CitaRepository extends JpaRepository<Cita, Long> {

    // Citas entre rangos de fecha y hora para un médico específico
    List<Cita> findByMedicoAndFechaHoraBetween(Medico medico, LocalDateTime start, LocalDateTime end);
    // Citas por paciente
    List<Cita> findByPaciente(Paciente paciente);
    // Citas por paciente entre rangos de fechas
    List<Cita> findByPacienteAndFechaHoraBetween(Paciente paciente, LocalDateTime inicio, LocalDateTime fin);
    // Buscar cita por ID
    Optional<Cita> findById(Long id);
    // Verificar si existe una cita en una fecha y hora específica que no esté cancelada
    boolean existsByFechaHoraAndCanceladaFalse(LocalDateTime fechaHora);
    // Citas entre fechas
    List<Cita> findByFechaHoraBetween(LocalDateTime inicio, LocalDateTime fin);
    // Citas por estado
    List<Cita> findByEstado(Estado estado);
    // Citas por mes y estado
    @Query("SELECT c FROM Cita c WHERE c.medico.id = :medicoId AND MONTH(c.fechaHora) = :mes AND YEAR(c.fechaHora) = :anio AND c.estado = :estado")
    List<Cita> findByMedicoIdAndMesAndEstado(@Param("medicoId") Long medicoId,
                                             @Param("mes") int mes,
                                             @Param("anio") int anio,
                                             @Param("estado") Estado estado);
    @Query("SELECT c FROM Cita c WHERE c.medico.id = :medicoId AND YEAR(c.fechaHora) = :anio AND c.estado = :estado")
    List<Cita> findByMedicoIdAndAnioAndEstado(@Param("medicoId") Long medicoId,
                                              @Param("anio") int anio,
                                              @Param("estado") Estado estado);

    // Citas por paciente en un año
    @Query("SELECT c FROM Cita c WHERE c.paciente.id = :pacienteId AND YEAR(c.fechaHora) = :anio")
    List<Cita> findByPacienteIdAndAnio(@Param("pacienteId") Long pacienteId,
                                       @Param("anio") int anio);

    List<Cita> findByMedicoIdAndFechaHoraBetween(Long medicoId, LocalDateTime inicio, LocalDateTime fin);
    @Query("SELECT c FROM Cita c WHERE c.fechaHora BETWEEN :startOfMonth AND :endOfMonth AND c.medico.id = :medicoId")
    List<Cita> findCitasByMonth(@Param("startOfMonth") LocalDateTime startOfMonth,
                                @Param("endOfMonth") LocalDateTime endOfMonth,
                                @Param("medicoId") Long medicoId);

    List<Cita> findAllByFechaHoraBetween(LocalDateTime start, LocalDateTime end);



}




