package ClinicasUpao.ClinicasUpaoG3.Repository;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Paciente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Long> {
    boolean existsByNombreAndApellido(String nombre,String apellido);
    Optional<Paciente> findByNombreAndApellido(String nombre, String apellido);
    Optional<Paciente> findByDocumentoIdentidad(String documentoIdentidad);
    Optional<Paciente> findByEmail(String email);

}