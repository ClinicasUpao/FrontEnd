package ClinicasUpao.ClinicasUpaoG3.Repository;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.TokenRestablecimiento;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface TokenRepository extends JpaRepository<TokenRestablecimiento, Long> {
    Optional<TokenRestablecimiento> findByToken(String token);
}
