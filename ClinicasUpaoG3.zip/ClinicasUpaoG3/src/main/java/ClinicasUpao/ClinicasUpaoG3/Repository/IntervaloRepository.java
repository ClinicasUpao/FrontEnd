package ClinicasUpao.ClinicasUpaoG3.Repository;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Intervalo;
import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Medico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface IntervaloRepository extends JpaRepository<Intervalo, Long> {

    @Query("SELECT i FROM Intervalo i WHERE i.medico.id = :medicoId AND i.fecha = :fecha AND i.horaInicio < :horaFin AND i.horaFin > :horaInicio")
    Optional<Intervalo> findByMedicoAndFechaAndHoraInicioBeforeAndHoraFinAfter(
            @Param("medicoId") Long medicoId,
            @Param("fecha") LocalDate fecha,
            @Param("horaInicio") LocalDateTime horaInicio,
            @Param("horaFin") LocalDateTime horaFin
    );
    @Query("SELECT i FROM Intervalo i WHERE i.medico.id = ?1 AND i.fecha = ?2 AND " +
            "i.horaInicio < ?3 AND i.horaFin > ?4")
    Optional<Intervalo> findFirstByMedicoAndFechaAndHoraInicioBeforeAndHoraFinAfter(
            Long medicoId, LocalDate fecha, LocalDateTime horaInicio, LocalDateTime horaFin);



}
