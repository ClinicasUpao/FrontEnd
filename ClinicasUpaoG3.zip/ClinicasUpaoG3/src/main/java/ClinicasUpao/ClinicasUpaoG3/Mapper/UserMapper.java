package ClinicasUpao.ClinicasUpaoG3.Mapper;

import ClinicasUpao.ClinicasUpaoG3.Domain.Entity.Usuario;
import ClinicasUpao.ClinicasUpaoG3.Dto.*;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class UserMapper {
    private final ModelMapper modelMapper;
    public UserMapper(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }
    public Usuario toUserEntity(SignupRequestDTO registrationDTO) {
        return modelMapper.map(registrationDTO, Usuario.class);

    }
    public UsuarioProfileDTO toUserProfileDTO(Usuario usuario) {
        UsuarioProfileDTO usuarioProfileDTO = modelMapper.map(usuario, UsuarioProfileDTO.class);

        if (usuario.getPaciente() != null) {
            usuarioProfileDTO.setNombre(usuario.getPaciente().getNombre());
            usuarioProfileDTO.setApellido(usuario.getPaciente().getApellido());
            usuarioProfileDTO.setEmail(usuario.getPaciente().getEmail());
            usuarioProfileDTO.setTelefono(usuario.getPaciente().getTelefono());
            usuarioProfileDTO.setDireccion(usuario.getPaciente().getDireccion());
            usuarioProfileDTO.setFechaNacimiento(usuario.getPaciente().getFechaNacimiento());
            usuarioProfileDTO.setDepartamento(usuario.getPaciente().getDepartamento());
            usuarioProfileDTO.setDistrito(usuario.getPaciente().getDistrito());
        }
        if (usuario.getMedico() != null) {
            usuarioProfileDTO.setNombre(usuario.getMedico().getNombre());
            usuarioProfileDTO.setApellido(usuario.getMedico().getApellido());
            usuarioProfileDTO.setEmail(usuario.getMedico().getEmail());
            usuarioProfileDTO.setTelefono(usuario.getMedico().getTelefono());
            usuarioProfileDTO.setDireccion(usuario.getMedico().getDireccion());
            usuarioProfileDTO.setFechaNacimiento(usuario.getMedico().getFechaNacimiento());
            usuarioProfileDTO.setDepartamento(usuario.getMedico().getDepartamento());
            usuarioProfileDTO.setDistrito(usuario.getMedico().getDistrito());
            usuarioProfileDTO.setColegiatura(usuario.getMedico().getColegiatura());
        }
        return usuarioProfileDTO;
    }


    public Usuario toUserEntity(SignupRequestMedicoDTO registrationDTO) {
        return modelMapper.map(registrationDTO, Usuario.class);
    }
    public AuthResponseDTO toAuthResponseDTO(Usuario usuario, String token) {
        AuthResponseDTO authResponseDTO = new AuthResponseDTO();
        authResponseDTO.setToken(token);

        if(usuario.getPaciente() != null) {
            authResponseDTO.setNombre(usuario.getPaciente().getNombre());
            authResponseDTO.setApellido(usuario.getPaciente().getApellido());
            authResponseDTO.setEmail(usuario.getPaciente().getEmail());
            authResponseDTO.setTelefono(usuario.getPaciente().getTelefono());
            authResponseDTO.setDireccion(usuario.getPaciente().getDireccion());
            authResponseDTO.setGenero(String.valueOf(usuario.getPaciente().getGenero()));

        }
        else if(usuario.getMedico() != null) {
            authResponseDTO.setNombre(usuario.getMedico().getNombre());
            authResponseDTO.setApellido(usuario.getMedico().getApellido());
            authResponseDTO.setEmail(usuario.getMedico().getEmail());
            authResponseDTO.setTelefono(usuario.getMedico().getTelefono());
            authResponseDTO.setDireccion(usuario.getMedico().getDireccion());
            authResponseDTO.setGenero(String.valueOf(usuario.getMedico().getGenero()));


        }
        authResponseDTO.setRole(usuario.getRole().getName().toString());
        return authResponseDTO;
    }
}
